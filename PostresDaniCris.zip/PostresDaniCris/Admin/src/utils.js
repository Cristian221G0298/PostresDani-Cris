const DIAS = ['DOM', 'LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB']
const DIAS_LARGOS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado']
const MESES = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC']
const MESES_MIN = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']

const pad = (n) => String(n).padStart(2, '0')

export const fecha = (valor) => (valor instanceof Date ? valor : new Date(valor))
export const mismoDia = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
export const sumarDias = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r }

export const dinero = (n) =>
  n === null || n === undefined ? '' : new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n)

export const horaCorta = (d) => {
  const x = fecha(d)
  const h = x.getHours()
  return `${h % 12 || 12}:${pad(x.getMinutes())} ${h >= 12 ? 'pm' : 'am'}`
}
export const diaSemana = (d) => DIAS[fecha(d).getDay()]
export const diaNumero = (d) => String(fecha(d).getDate())
export const mesCorto = (d) => MESES[fecha(d).getMonth()]
export const fechaCorta = (d) => { const x = fecha(d); return `${x.getDate()} ${MESES_MIN[x.getMonth()]} ${x.getFullYear()}` }
export const fechaDiaMes = (d) => { const x = fecha(d); return `${x.getDate()} ${MESES_MIN[x.getMonth()]}` }

/** "hoy a las 9:00 pm", "mañana a las 6:00 pm", "el sábado a las 8:00 pm" */
export function cuando(d) {
  const x = fecha(d)
  const hoy = new Date()
  if (mismoDia(x, hoy)) return `hoy a las ${horaCorta(x)}`
  if (mismoDia(x, sumarDias(hoy, 1))) return `mañana a las ${horaCorta(x)}`
  if (x < sumarDias(hoy, 7)) return `el ${DIAS_LARGOS[x.getDay()]} a las ${horaCorta(x)}`
  return `el ${fechaDiaMes(x)} a las ${horaCorta(x)}`
}

// Fecha local en formato ISO sin zona (2026-10-14T21:00:00), como la espera la API
export const aIsoLocal = (d) => {
  const x = fecha(d)
  return `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}T${pad(x.getHours())}:${pad(x.getMinutes())}:00`
}
export const aInputFechaHora = (d) => aIsoLocal(d).slice(0, 16)
export const aInputFecha = (d) => aIsoLocal(d).slice(0, 10)
export const aInputHora = (d) => aIsoLocal(d).slice(11, 16)

/** Atajos para "Se oculta el": hoy 9:00 pm (o mañana si ya pasó), 24 h y 48 h. */
export function atajosExpiracion() {
  const ahora = new Date()
  const noche = new Date(ahora)
  noche.setHours(21, 0, 0, 0)
  const lista = []
  if (noche > ahora) lista.push({ etiqueta: 'Hoy 9:00 pm', fecha: noche })
  else lista.push({ etiqueta: 'Mañana 9:00 pm', fecha: sumarDias(noche, 1) })
  lista.push({ etiqueta: '24 h', fecha: new Date(ahora.getTime() + 24 * 3600 * 1000) })
  lista.push({ etiqueta: '48 h', fecha: new Date(ahora.getTime() + 48 * 3600 * 1000) })
  return lista
}

/** Convierte "$1,250.50" o "150" en número; vacío = 0; texto inválido = NaN */
export function parseMonto(texto) {
  const limpio = String(texto ?? '').replace(/[$,\s]/g, '')
  if (limpio === '') return 0
  return /^\d+(\.\d{1,2})?$/.test(limpio) ? Number(limpio) : NaN
}

// Colores de apoyo para las fotos de ejemplo cuando una publicación no tiene imagen
const COLORES = ['#B98A5E', '#E7A8B0', '#D9B36B', '#6B3E26', '#C9954A', '#B8878F', '#A9C27A', '#C98F4A']
export const colorDe = (texto = '') => {
  let h = 0
  for (const c of texto) h = (h * 31 + c.charCodeAt(0)) >>> 0
  return COLORES[h % COLORES.length]
}
