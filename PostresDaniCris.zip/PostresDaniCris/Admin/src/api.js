// Cliente de la API REST. Todas las rutas son relativas (/api/...).
export class ApiError extends Error {
  constructor(status, mensaje, errores) {
    super(mensaje)
    this.status = status
    this.errores = errores || {}
  }
}

async function solicitar(metodo, url, cuerpo, esFormulario = false) {
  let respuesta
  try {
    respuesta = await fetch(url, {
      method: metodo,
      credentials: 'same-origin',
      headers: cuerpo && !esFormulario ? { 'Content-Type': 'application/json' } : undefined,
      body: cuerpo ? (esFormulario ? cuerpo : JSON.stringify(cuerpo)) : undefined,
    })
  } catch {
    throw new ApiError(0, 'No se pudo conectar con el servidor')
  }

  if (respuesta.status === 401 && !url.includes('/auth/login')) {
    window.dispatchEvent(new Event('sesion-expirada'))
  }

  let datos = null
  if (respuesta.status !== 204) {
    const texto = await respuesta.text()
    if (texto) {
      try { datos = JSON.parse(texto) } catch { datos = null }
    }
  }
  if (!respuesta.ok) {
    throw new ApiError(respuesta.status, datos?.mensaje || 'Ocurrió un error, inténtalo de nuevo', datos?.errores)
  }
  return datos
}

const qs = (obj) => {
  const p = new URLSearchParams()
  Object.entries(obj).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') p.set(k, v) })
  const s = p.toString()
  return s ? `?${s}` : ''
}

export const api = {
  // Sesión
  login: (usuario, contrasena) => solicitar('POST', '/api/auth/login', { usuario, contrasena }),
  logout: () => solicitar('POST', '/api/auth/logout'),
  me: () => solicitar('GET', '/api/auth/me'),
  // Catálogos
  categorias: () => solicitar('GET', '/api/categorias'),
  // Publicaciones
  publicaciones: (filtros = {}) => solicitar('GET', '/api/publicaciones' + qs(filtros)),
  ocultas: () => solicitar('GET', '/api/publicaciones/ocultas'),
  resumenPublicaciones: () => solicitar('GET', '/api/publicaciones/resumen'),
  publicacion: (id) => solicitar('GET', `/api/publicaciones/${id}`),
  crearPublicacion: (datos) => solicitar('POST', '/api/publicaciones', datos),
  actualizarPublicacion: (id, datos) => solicitar('PUT', `/api/publicaciones/${id}`, datos),
  eliminarPublicacion: (id) => solicitar('DELETE', `/api/publicaciones/${id}`),
  republicar: (id, fechaExpiracion) => solicitar('POST', `/api/publicaciones/${id}/republicar`, { fechaExpiracion }),
  subirImagenes: (id, archivos) => {
    const form = new FormData()
    archivos.forEach((a) => form.append('archivos', a))
    return solicitar('POST', `/api/publicaciones/${id}/imagenes`, form, true)
  },
  eliminarImagen: (id, imagenId) => solicitar('DELETE', `/api/publicaciones/${id}/imagenes/${imagenId}`),
  // Pedidos
  pedidos: (estadoId) => solicitar('GET', '/api/pedidos' + qs({ estadoId })),
  resumenPedidos: (estadoId) => solicitar('GET', '/api/pedidos/resumen' + qs({ estadoId })),
  pedido: (id) => solicitar('GET', `/api/pedidos/${id}`),
  crearPedido: (datos) => solicitar('POST', '/api/pedidos', datos),
  actualizarPedido: (id, datos) => solicitar('PUT', `/api/pedidos/${id}`, datos),
  cambiarEstadoPedido: (id, estadoId) => solicitar('PATCH', `/api/pedidos/${id}/estado`, { estadoId }),
  eliminarPedido: (id) => solicitar('DELETE', `/api/pedidos/${id}`),
}
