import { createContext, useCallback, useContext, useRef, useState } from 'react'
import Icon from './Icon.jsx'

const ToastContext = createContext(null)
export const useToast = () => useContext(ToastContext)

export function ToastProvider({ children }) {
  const [aviso, setAviso] = useState(null)
  const temporizador = useRef(null)

  const mostrar = useCallback((mensaje, tipo = 'exito') => {
    clearTimeout(temporizador.current)
    setAviso({ mensaje, tipo })
    temporizador.current = setTimeout(() => setAviso(null), 3500)
  }, [])

  return (
    <ToastContext.Provider value={{ mostrar }}>
      {children}
      {aviso && (
        <div className={`toast ${aviso.tipo}`} role="status">
          <Icon name={aviso.tipo === 'exito' ? 'check' : 'alert'} size={20} />
          <span>{aviso.mensaje}</span>
        </div>
      )}
    </ToastContext.Provider>
  )
}
