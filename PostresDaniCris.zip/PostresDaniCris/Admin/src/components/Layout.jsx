import { NavLink, Outlet, useLocation, useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../auth.jsx'
import Icon from './Icon.jsx'
import { Marca } from './ui.jsx'

export default function Layout() {
  const { logout } = useAuth()
  const ir = useNavigate()
  const { pathname } = useLocation()
  const salir = async () => { await logout(); ir('/login') }

  return (
    <div className="app">
      {/* Escritorio: menú lateral */}
      <aside className="lateral">
        <Marca />
        <nav>
          <NavLink to="/" end className="lateral-item"><Icon name="grid" />Publicaciones</NavLink>
          <NavLink to="/pedidos" className="lateral-item"><Icon name="cal" />Pedidos</NavLink>
          <NavLink to="/ocultas" className="lateral-item"><Icon name="eyeoff" />Ocultas</NavLink>
        </nav>
        <button className="lateral-salir" onClick={salir}><Icon name="logout" size={18} />Cerrar sesión</button>
      </aside>

      <main className="principal">
        {/* Celular: encabezado con marca, acceso a Pedidos y salir (solo en la pantalla de inicio) */}
        {pathname === '/' && (
          <header className="movil-encabezado">
            <Marca pequena subtitulo="Postres hechos con amor" />
            <div className="movil-acciones">
              <Link to="/pedidos" className="pill pill-cafe"><Icon name="cal" size={15} />Pedidos</Link>
              <button className="icono-btn" onClick={salir} aria-label="Cerrar sesión"><Icon name="logout" size={17} /></button>
            </div>
          </header>
        )}
        <Outlet />
      </main>
    </div>
  )
}
