import { useNavigate } from 'react-router-dom'
import Icon from './Icon.jsx'
import { aInputFechaHora, atajosExpiracion, cuando, colorDe, fechaDiaMes, dinero } from '../utils.js'

export function Marca({ pequena = false, subtitulo = 'Panel de administración' }) {
  return (
    <div className="marca">
      <div className={`marca-logo ${pequena ? 'sm' : ''}`}><span>D&amp;C</span></div>
      <div>
        <div className="marca-nombre">Dani &amp; Cris</div>
        <div className="marca-sub">{subtitulo}</div>
      </div>
    </div>
  )
}

export const Pill = ({ children, tipo = 'oro', ...props }) => <span className={`pill pill-${tipo}`} {...props}>{children}</span>

/** Encabezado de página: título (y flecha de regreso en móvil) + acciones a la derecha. */
export function EncabezadoPagina({ titulo, regresarA, ocultoMovil = false, children }) {
  const ir = useNavigate()
  return (
    <div className={`encabezado ${ocultoMovil ? 'oculto-movil' : ''}`}>
      <div className="encabezado-izq">
        {regresarA && (
          <button className="btn-atras" onClick={() => ir(regresarA)} aria-label="Regresar"><Icon name="back" size={20} /></button>
        )}
        <h1>{titulo}</h1>
      </div>
      <div className="encabezado-acciones">{children}</div>
    </div>
  )
}

export function Campo({ etiqueta, error, children, className = '' }) {
  return (
    <label className={`campo ${error ? 'con-error' : ''} ${className}`}>
      <span className="campo-etiqueta">{etiqueta}</span>
      {children}
      {error && <span className="campo-error"><Icon name="alert" size={15} />{error}</span>}
    </label>
  )
}

export function Selector({ opciones, valor, onCambio }) {
  return (
    <div className="selector" role="tablist">
      {opciones.map((o) => (
        <button type="button" key={o.valor} className={valor === o.valor ? 'activo' : ''} onClick={() => onCambio(o.valor)}>{o.etiqueta}</button>
      ))}
    </div>
  )
}

export function Interruptor({ activo, onCambio, etiqueta }) {
  return (
    <button type="button" className="interruptor" onClick={() => onCambio(!activo)} role="switch" aria-checked={activo}>
      <span className={`interruptor-riel ${activo ? 'activo' : ''}`}><span /></span>
      <span>{etiqueta}</span>
    </button>
  )
}

export function Pasos({ actual, etiqueta }) {
  return (
    <div className="pasos">
      <div className="pasos-barras"><span className={actual >= 1 ? 'on' : ''} /><span className={actual >= 2 ? 'on' : ''} /></div>
      <div className="pasos-texto">Paso {actual} de 2 · {etiqueta}</div>
    </div>
  )
}

export function AvisoError({ children }) {
  return <div className="aviso-error"><Icon name="alert" size={20} />{children}</div>
}

/** Foto de la publicación: la primera imagen, o un bloque de color con el título si aún no tiene. */
export function Foto({ publicacion, alto }) {
  const imagen = publicacion.imagenes?.[0]
  return imagen ? (
    <img className="foto" style={{ height: alto }} src={imagen.ruta} alt={publicacion.titulo} />
  ) : (
    <div className="foto foto-vacia" style={{ height: alto, background: colorDe(publicacion.titulo) }}>
      <span>{publicacion.titulo}</span>
    </div>
  )
}

export function infoPublicacion(p, oculta = false) {
  if (oculta) return { icono: 'clock', texto: `Se ocultó el ${fechaDiaMes(p.fechaExpiracion)}` }
  if (p.temporal) {
    const quedan = p.cantidad !== null && p.cantidad !== undefined ? ` · quedan ${p.cantidad}` : ''
    return { icono: 'clock', texto: `Se oculta ${cuando(p.fechaExpiracion)}${quedan}` }
  }
  if (p.categoriaNombre === 'Nuevos productos') {
    const dias = Math.max(0, 7 - Math.floor((Date.now() - new Date(p.fechaPublicacion).getTime()) / 86400000))
    return { icono: 'clock', texto: `Pasa a sin categoría en ${dias} día${dias === 1 ? '' : 's'}` }
  }
  return { icono: 'pin', texto: 'Siempre visible' }
}

export const textoPrecio = (p) => (p.precio === null || p.precio === undefined ? '' : `${p.precioDesde ? 'Desde ' : ''}${dinero(p.precio)}`)

export function TarjetaPublicacion({ p, oculta = false, onEditar, onEliminar, onRepublicar }) {
  const info = infoPublicacion(p, oculta)
  return (
    <article className="tarjeta">
      <Foto publicacion={p} alto={oculta ? 100 : 110} />
      <div className="tarjeta-cuerpo">
        <div className="tarjeta-tags">
          {oculta ? <Pill tipo="rojo">Expirada</Pill> : (
            <>
              {p.categoriaNombre && <Pill tipo="oro">{p.categoriaNombre}</Pill>}
              <Pill tipo={p.temporal ? 'rosa' : 'gris'}>{p.temporal ? 'Temporal' : 'Permanente'}</Pill>
              {!p.disponible && <Pill tipo="rojo">Agotado</Pill>}
            </>
          )}
        </div>
        <div className="tarjeta-titulo">
          <h3>{p.titulo}</h3>
          <span className="precio">{textoPrecio(p)}</span>
        </div>
        {p.descripcion && <p className="tarjeta-desc">{p.descripcion}</p>}
        <div className="tarjeta-info"><Icon name={info.icono} size={16} color="var(--gold)" /><span>{info.texto}</span></div>
        <div className="tarjeta-acciones">
          {oculta
            ? <button className="btn btn-claro btn-sm" onClick={onRepublicar}><Icon name="redo" size={18} />Republicar</button>
            : <button className="btn btn-claro btn-sm" onClick={onEditar}><Icon name="edit" size={18} />Editar</button>}
          <button className="btn btn-peligro-suave btn-sm" onClick={onEliminar}><Icon name="trash" size={18} />Eliminar</button>
        </div>
      </div>
    </article>
  )
}

/** Elige cuándo se oculta: atajos (hoy 9 pm, 24 h, 48 h) y fecha personalizada. */
export function SelectorExpiracion({ valor, onCambio, error }) {
  const atajos = atajosExpiracion()
  return (
    <div className={`expiracion ${error ? 'con-error' : ''}`}>
      <div className="chips">
        {atajos.map((a) => {
          const iso = aInputFechaHora(a.fecha)
          return (
            <button type="button" key={a.etiqueta} className={`chip ${valor === iso ? 'activo-borde' : ''}`} onClick={() => onCambio(iso)}>{a.etiqueta}</button>
          )
        })}
      </div>
      <input type="datetime-local" value={valor} onChange={(e) => onCambio(e.target.value)} />
      {error && <span className="campo-error"><Icon name="alert" size={15} />{error}</span>}
    </div>
  )
}
