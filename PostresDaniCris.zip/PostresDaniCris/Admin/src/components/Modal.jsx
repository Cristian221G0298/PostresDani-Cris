import { useEffect, useState } from 'react'

export function Modal({ onCerrar, children, ancho = 480, alFondo = false }) {
  useEffect(() => {
    const tecla = (e) => e.key === 'Escape' && onCerrar()
    window.addEventListener('keydown', tecla)
    return () => window.removeEventListener('keydown', tecla)
  }, [onCerrar])

  return (
    <div className={`modal-fondo ${alFondo ? 'al-fondo' : ''}`} onMouseDown={(e) => e.target === e.currentTarget && onCerrar()}>
      <div className="modal" style={{ maxWidth: ancho }} role="dialog" aria-modal="true">
        {children}
      </div>
    </div>
  )
}

export function ConfirmarEliminar({ titulo, mensaje, onConfirmar, onCancelar }) {
  const [trabajando, setTrabajando] = useState(false)
  const confirmar = async () => {
    setTrabajando(true)
    try { await onConfirmar() } finally { setTrabajando(false) }
  }
  return (
    <Modal onCerrar={onCancelar} ancho={460}>
      <h2 className="modal-titulo">{titulo}</h2>
      <p className="modal-texto">{mensaje}</p>
      <div className="modal-botones">
        <button className="btn btn-claro" onClick={onCancelar} disabled={trabajando}>Cancelar</button>
        <button className="btn btn-peligro" onClick={confirmar} disabled={trabajando}>{trabajando ? 'Eliminando…' : 'Eliminar'}</button>
      </div>
    </Modal>
  )
}
