import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth.jsx'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import Publicaciones from './pages/Publicaciones.jsx'
import PublicacionForm from './pages/PublicacionForm.jsx'
import Ocultas from './pages/Ocultas.jsx'
import Pedidos from './pages/Pedidos.jsx'
import PedidoForm from './pages/PedidoForm.jsx'

function Protegida({ children }) {
  const { usuario, cargando } = useAuth()
  if (cargando) return <div className="cargando-pagina">Cargando…</div>
  return usuario ? children : <Navigate to="/login" replace />
}

export default function App() {
  const { usuario, cargando } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={!cargando && usuario ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<Protegida><Layout /></Protegida>}>
        <Route path="/" element={<Publicaciones />} />
        <Route path="/publicaciones/nueva" element={<PublicacionForm />} />
        <Route path="/publicaciones/:id/editar" element={<PublicacionForm />} />
        <Route path="/ocultas" element={<Ocultas />} />
        <Route path="/pedidos" element={<Pedidos />} />
        <Route path="/pedidos/nuevo" element={<PedidoForm />} />
        <Route path="/pedidos/:id/editar" element={<PedidoForm />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
