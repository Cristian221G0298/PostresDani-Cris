import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { api } from './api.js'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null)
  const [cargando, setCargando] = useState(true)

  useEffect(() => {
    api.me().then((r) => setUsuario(r.usuario)).catch(() => setUsuario(null)).finally(() => setCargando(false))
    const expirada = () => setUsuario(null)
    window.addEventListener('sesion-expirada', expirada)
    return () => window.removeEventListener('sesion-expirada', expirada)
  }, [])

  const login = useCallback(async (user, pass) => {
    const r = await api.login(user, pass)
    setUsuario(r.usuario)
  }, [])

  const logout = useCallback(async () => {
    try { await api.logout() } catch { /* aunque falle, se cierra la sesión en pantalla */ }
    setUsuario(null)
  }, [])

  return <AuthContext.Provider value={{ usuario, cargando, login, logout }}>{children}</AuthContext.Provider>
}
