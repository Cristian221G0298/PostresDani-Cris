import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import { Campo, Pasos, AvisoError, EncabezadoPagina } from '../components/ui.jsx'
import { useToast } from '../components/Toast.jsx'
import { aInputFecha, aInputHora, diaNumero, diaSemana, dinero, fechaDiaMes, fechaCorta, horaCorta, parseMonto } from '../utils.js'

const PASO_1 = ['aNombreDe', 'detallesPedido', 'anticipo', 'resta']
const MONTO_MALO = 'Ingresa un monto válido (solo números)'

export default function PedidoForm() {
  const { id } = useParams()
  const editando = Boolean(id)
  const ir = useNavigate()
  const { mostrar } = useToast()

  const [paso, setPaso] = useState(1)
  const [f, setF] = useState({ aNombreDe: '', detallesPedido: '', anticipo: '', resta: '', fechaAgendado: aInputFecha(new Date()), fechaEntrega: '', horaEntrega: '', lugarEntrega: '' })
  const [errores, setErrores] = useState({})
  const [cargando, setCargando] = useState(editando)
  const [guardando, setGuardando] = useState(false)
  const [cercanas, setCercanas] = useState([])

  const cambiar = (campo, valor) => { setF((x) => ({ ...x, [campo]: valor })); setErrores((e) => ({ ...e, [campo]: undefined })) }

  useEffect(() => { api.pedidos(1).then((l) => setCercanas(l.slice(0, 4))).catch(() => {}) }, [])
  useEffect(() => {
    if (!editando) return
    api.pedido(id).then((p) => setF({
      aNombreDe: p.aNombreDe, detallesPedido: p.detallesPedido,
      anticipo: String(p.anticipo), resta: String(p.resta),
      fechaAgendado: aInputFecha(p.fechaAgendado), fechaEntrega: aInputFecha(p.fechaEntrega), horaEntrega: aInputHora(p.fechaEntrega),
      lugarEntrega: p.lugarEntrega,
    })).catch((e) => { mostrar(e.message, 'error'); ir('/pedidos') }).finally(() => setCargando(false))
  }, [id, editando, ir, mostrar])

  const validarPaso1 = () => {
    const e = {}
    if (!f.aNombreDe.trim()) e.aNombreDe = 'Escribe a nombre de quién es el pedido'
    else if (f.aNombreDe.trim().length > 120) e.aNombreDe = 'El nombre no puede pasar de 120 caracteres'
    if (!f.detallesPedido.trim()) e.detallesPedido = 'Describe el pedido'
    if (Number.isNaN(parseMonto(f.anticipo))) e.anticipo = MONTO_MALO
    if (Number.isNaN(parseMonto(f.resta))) e.resta = MONTO_MALO
    return e
  }
  const validarPaso2 = () => {
    const e = {}
    if (!f.fechaAgendado) e.fechaAgendado = 'Indica la fecha en que se agendó'
    if (!f.fechaEntrega) e.fechaEntrega = 'Indica la fecha de entrega'
    if (!f.horaEntrega) e.horaEntrega = 'Indica la hora de entrega'
    if (!f.lugarEntrega.trim()) e.lugarEntrega = 'Escribe el lugar de entrega'
    return e
  }

  const siguiente = () => {
    const e = validarPaso1()
    setErrores(e)
    if (Object.keys(e).length === 0) setPaso(2)
  }

  const guardar = async () => {
    const e1 = validarPaso1()
    const e2 = validarPaso2()
    setErrores({ ...e1, ...e2 })
    if (Object.keys(e1).length) { setPaso(1); return }
    if (Object.keys(e2).length) return
    const datos = {
      aNombreDe: f.aNombreDe.trim(),
      detallesPedido: f.detallesPedido.trim(),
      anticipo: parseMonto(f.anticipo),
      resta: parseMonto(f.resta),
      fechaAgendado: `${f.fechaAgendado}T00:00:00`,
      fechaEntrega: `${f.fechaEntrega}T${f.horaEntrega}:00`,
      lugarEntrega: f.lugarEntrega.trim(),
    }
    setGuardando(true)
    try {
      if (editando) await api.actualizarPedido(id, datos)
      else await api.crearPedido(datos)
      mostrar(editando ? 'Pedido actualizado correctamente' : 'Pedido agregado correctamente')
      ir('/pedidos')
    } catch (err) {
      if (err.errores && Object.keys(err.errores).length) {
        setErrores(err.errores)
        if (PASO_1.some((c) => err.errores[c])) setPaso(1)
      } else mostrar(err.message, 'error')
      setGuardando(false)
    }
  }

  const hayErrores = Object.values(errores).some(Boolean)
  const anticipo = Number.isNaN(parseMonto(f.anticipo)) ? 0 : parseMonto(f.anticipo)
  const resta = Number.isNaN(parseMonto(f.resta)) ? 0 : parseMonto(f.resta)
  const entrega = f.fechaEntrega && f.horaEntrega ? new Date(`${f.fechaEntrega}T${f.horaEntrega}:00`) : null

  if (cargando) return <div className="cargando-pagina">Cargando…</div>

  return (
    <>
      <EncabezadoPagina titulo={editando ? 'Editar pedido' : 'Nuevo pedido'} regresarA="/pedidos" />
      <div className="formulario-pagina">
        <form className="formulario-tarjeta" onSubmit={(e) => e.preventDefault()} noValidate>
          <Pasos actual={paso} etiqueta={paso === 1 ? 'Pedido y pago' : 'Entrega'} />
          {hayErrores && <AvisoError>Revisa los campos marcados en rojo</AvisoError>}

          {paso === 1 && (
            <>
              <Campo etiqueta="A nombre de" error={errores.aNombreDe}>
                <input value={f.aNombreDe} onChange={(e) => cambiar('aNombreDe', e.target.value)} placeholder="Nombre de quien hace el pedido" />
              </Campo>
              <Campo etiqueta="Detalles del pedido" error={errores.detallesPedido}>
                <textarea rows={5} value={f.detallesPedido} onChange={(e) => cambiar('detallesPedido', e.target.value)} placeholder="Qué incluye el pedido, cantidades, sabores…" />
              </Campo>
              <div className="dos-columnas">
                <Campo etiqueta="Anticipo pagado" error={errores.anticipo}>
                  <input inputMode="decimal" value={f.anticipo} onChange={(e) => cambiar('anticipo', e.target.value)} placeholder="$0.00" />
                </Campo>
                <Campo etiqueta="Resta por pagar" error={errores.resta}>
                  <input inputMode="decimal" value={f.resta} onChange={(e) => cambiar('resta', e.target.value)} placeholder="$0.00" />
                </Campo>
              </div>
              <div className="formulario-botones"><button className="btn btn-cafe" onClick={siguiente}>Siguiente</button></div>
            </>
          )}

          {paso === 2 && (
            <>
              <Campo etiqueta="Fecha en que se agendó" error={errores.fechaAgendado}>
                <input type="date" value={f.fechaAgendado} onChange={(e) => cambiar('fechaAgendado', e.target.value)} />
              </Campo>
              <div className="dos-columnas">
                <Campo etiqueta="Fecha de entrega" error={errores.fechaEntrega}>
                  <input type="date" value={f.fechaEntrega} onChange={(e) => cambiar('fechaEntrega', e.target.value)} />
                </Campo>
                <Campo etiqueta="Hora" error={errores.horaEntrega}>
                  <input type="time" value={f.horaEntrega} onChange={(e) => cambiar('horaEntrega', e.target.value)} />
                </Campo>
              </div>
              <Campo etiqueta="Lugar de entrega" error={errores.lugarEntrega}>
                <input value={f.lugarEntrega} onChange={(e) => cambiar('lugarEntrega', e.target.value)} placeholder="Dirección o punto de entrega" />
              </Campo>
              <div className="nota"><Icon name="bulb" size={22} color="var(--gold)" /><span>Al guardar, el pedido aparece en “Próximos” ordenado por su fecha de entrega.</span></div>
              <div className="formulario-botones">
                <button className="btn btn-claro" onClick={() => setPaso(1)} disabled={guardando}>Atrás</button>
                <button className="btn btn-cafe" onClick={guardar} disabled={guardando}>{guardando ? 'Guardando…' : editando ? 'Guardar cambios' : 'Guardar pedido'}</button>
              </div>
            </>
          )}
        </form>

        {/* Escritorio: resumen del pedido y entregas cercanas */}
        <aside className="lateral-derecho">
          <div className="resumen-pedido">
            <h3>Resumen del pedido</h3>
            <div className="resumen-fila"><span>A nombre de</span><strong>{f.aNombreDe.trim() || '—'}</strong></div>
            <div className="resumen-bloque"><span>Detalles</span><p>{f.detallesPedido.trim() || '—'}</p></div>
            <hr />
            <div className="resumen-fila"><span>Anticipo</span><strong>{dinero(anticipo)}</strong></div>
            <div className="resumen-fila"><span>Resta</span><strong>{dinero(resta)}</strong></div>
            <div className="resumen-fila total"><span>Total</span><strong>{dinero(anticipo + resta)}</strong></div>
            <hr />
            <div className="resumen-fila"><span>Entrega</span><strong>{entrega ? `${fechaDiaMes(entrega)} · ${horaCorta(entrega)}` : 'Pendiente'}</strong></div>
            <div className="resumen-fila"><span>Lugar</span><strong>{f.lugarEntrega.trim() || 'Pendiente'}</strong></div>
          </div>
          <div className="nota nota-vertical">
            <div className="nota-titulo"><Icon name="cal" size={20} color="var(--gold)" />Entregas cercanas</div>
            {cercanas.map((p) => (
              <div className="lado-item" key={p.id}>
                <span className="lado-dia">{diaNumero(new Date(p.fechaEntrega))}</span>
                <div><strong>{p.aNombreDe}</strong><small>{diaSemana(new Date(p.fechaEntrega))} {fechaDiaMes(new Date(p.fechaEntrega)).toUpperCase()} · {horaCorta(new Date(p.fechaEntrega))}</small></div>
              </div>
            ))}
            {cercanas.length === 0 && <small className="suave">Aún no hay entregas próximas.</small>}
            <p>Revisa que la fecha no se empalme con otra entrega.</p>
          </div>
        </aside>
      </div>
    </>
  )
}
