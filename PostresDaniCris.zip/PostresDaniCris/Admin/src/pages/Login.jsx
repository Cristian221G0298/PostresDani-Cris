import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../auth.jsx'
import { Campo, AvisoError } from '../components/ui.jsx'

export default function Login() {
  const { login } = useAuth()
  const ir = useNavigate()
  const [usuario, setUsuario] = useState('')
  const [contrasena, setContrasena] = useState('')
  const [errores, setErrores] = useState({})
  const [error, setError] = useState('')
  const [enviando, setEnviando] = useState(false)

  const enviar = async (e) => {
    e.preventDefault()
    const nuevos = {}
    if (!usuario.trim()) nuevos.usuario = 'Escribe tu usuario'
    if (!contrasena) nuevos.contrasena = 'Escribe tu contraseña'
    setErrores(nuevos)
    setError('')
    if (Object.keys(nuevos).length) return
    setEnviando(true)
    try {
      await login(usuario.trim(), contrasena)
      ir('/')
    } catch (err) {
      setError(err.status === 401 ? 'Usuario o contraseña incorrectos' : err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="login">
      <section className="login-marca">
        <div className="marca-logo grande"><span>Dani<br />&amp; Cris</span></div>
        <h2>Postres Dani &amp; Cris</h2>
        <p className="login-sub">Panel de administración</p>
        <div className="login-burbujas">
          {[['Hojarascas', '#E7A8B0'], ['Besitos', '#D9B36B'], ['Brownies', '#6B3E26'], ['Pay', '#B98A5E']].map(([t, c]) => (
            <span key={t} style={{ background: c }}>{t}</span>
          ))}
        </div>
        <p className="login-texto">Publica lo disponible, lleva tus pedidos y mantén tu menú al día.</p>
      </section>

      <section className="login-acceso">
        <form className="login-form" onSubmit={enviar} noValidate>
          <div className="marca-logo grande solo-movil"><span>Dani<br />&amp; Cris</span></div>
          <h1>Acceso administradores</h1>
          <p className="texto-suave">Ingresa con tu usuario y contraseña.</p>
          {error && <AvisoError>{error}</AvisoError>}
          <Campo etiqueta="Usuario" error={errores.usuario}>
            <input value={usuario} onChange={(e) => setUsuario(e.target.value)} autoComplete="username" placeholder="Tu usuario" />
          </Campo>
          <Campo etiqueta="Contraseña" error={errores.contrasena}>
            <input type="password" value={contrasena} onChange={(e) => setContrasena(e.target.value)} autoComplete="current-password" placeholder="••••••••" />
          </Campo>
          <button className="btn btn-cafe btn-grande" disabled={enviando}>{enviando ? 'Entrando…' : 'Iniciar sesión'}</button>
          <p className="texto-chico">Solo administradores. No hay registro de nuevos usuarios.</p>
        </form>
      </section>
    </div>
  )
}
