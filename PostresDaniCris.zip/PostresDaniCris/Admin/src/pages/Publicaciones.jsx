import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import { EncabezadoPagina, TarjetaPublicacion } from '../components/ui.jsx'
import { ConfirmarEliminar } from '../components/Modal.jsx'
import { useToast } from '../components/Toast.jsx'
import { useNavigate } from 'react-router-dom'

export default function Publicaciones() {
  const ir = useNavigate()
  const { mostrar } = useToast()
  const [lista, setLista] = useState(null)
  const [resumen, setResumen] = useState(null)
  const [categorias, setCategorias] = useState([])
  const [categoriaId, setCategoriaId] = useState(null)
  const [buscar, setBuscar] = useState('')
  const [error, setError] = useState('')
  const [porEliminar, setPorEliminar] = useState(null)

  const cargarResumen = useCallback(() => api.resumenPublicaciones().then(setResumen).catch(() => {}), [])
  useEffect(() => { api.categorias().then(setCategorias).catch(() => {}); cargarResumen() }, [cargarResumen])

  const cargar = useCallback(() => {
    api.publicaciones({ buscar: buscar.trim(), categoriaId })
      .then((r) => { setLista(r); setError('') })
      .catch((e) => setError(e.message))
  }, [buscar, categoriaId])

  useEffect(() => {
    const t = setTimeout(cargar, 250)
    return () => clearTimeout(t)
  }, [cargar])

  const eliminar = async () => {
    try {
      await api.eliminarPublicacion(porEliminar.id)
      mostrar('Publicación eliminada correctamente')
      setPorEliminar(null)
      cargar(); cargarResumen()
    } catch (e) {
      mostrar(e.message, 'error')
      setPorEliminar(null)
    }
  }

  const datos = resumen && [
    ['Publicaciones activas', resumen.activas, 'grid'],
    ['Temporales', resumen.temporales, 'clock'],
    ['Permanentes', resumen.permanentes, 'box'],
    ['Ocultas', resumen.ocultas, 'eyeoff'],
  ]

  return (
    <>
      <EncabezadoPagina titulo="Publicaciones" ocultoMovil>
        <div className="buscador">
          <Icon name="search" size={18} color="var(--gold)" />
          <input value={buscar} onChange={(e) => setBuscar(e.target.value)} placeholder="Buscar publicaciones…" />
        </div>
        <Link to="/publicaciones/nueva" className="btn btn-oro btn-redondo solo-escritorio"><Icon name="plus" size={18} />Nueva publicación</Link>
      </EncabezadoPagina>

      <div className="buscador buscador-movil">
        <Icon name="search" size={18} color="var(--gold)" />
        <input value={buscar} onChange={(e) => setBuscar(e.target.value)} placeholder="Buscar publicaciones…" />
      </div>

      {datos && (
        <div className="estadisticas">
          {datos.map(([etiqueta, numero, icono]) => (
            <div className="estadistica" key={etiqueta}>
              <span className="estadistica-icono"><Icon name={icono} size={24} color="var(--gold)" /></span>
              <div><strong>{numero}</strong><span>{etiqueta}</span></div>
            </div>
          ))}
        </div>
      )}

      <div className="chips">
        <button className={`chip ${categoriaId === null ? 'activo' : ''}`} onClick={() => setCategoriaId(null)}>Todas</button>
        {categorias.map((c) => (
          <button key={c.id} className={`chip ${categoriaId === c.id ? 'activo' : ''}`} onClick={() => setCategoriaId(c.id)}>{c.nombre}</button>
        ))}
      </div>

      <Link to="/ocultas" className="pill-ocultas solo-movil">
        <Icon name="eyeoff" size={15} />Publicaciones ocultas{resumen ? ` · ${resumen.ocultas}` : ''}
      </Link>

      {error && <div className="vacio">{error}</div>}
      {lista && lista.length === 0 && !error && (
        <div className="vacio">
          <Icon name="grid" size={36} color="var(--gold)" />
          <h3>No hay publicaciones</h3>
          <p>{buscar || categoriaId ? 'Prueba con otra búsqueda o categoría.' : 'Crea la primera con el botón “Nueva publicación”.'}</p>
        </div>
      )}
      {lista && lista.length > 0 && (
        <div className="rejilla">
          {lista.map((p) => (
            <TarjetaPublicacion key={p.id} p={p}
              onEditar={() => ir(`/publicaciones/${p.id}/editar`)}
              onEliminar={() => setPorEliminar(p)} />
          ))}
        </div>
      )}

      <Link to="/publicaciones/nueva" className="fab solo-movil"><Icon name="plus" size={20} />Nueva publicación</Link>

      {porEliminar && (
        <ConfirmarEliminar titulo="¿Eliminar publicación?"
          mensaje={`Se eliminará “${porEliminar.titulo}” y sus fotos. Esta acción no se puede deshacer.`}
          onConfirmar={eliminar} onCancelar={() => setPorEliminar(null)} />
      )}
    </>
  )
}
