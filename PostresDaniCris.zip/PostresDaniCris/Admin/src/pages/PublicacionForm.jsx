import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import { Campo, Selector, Interruptor, Pasos, AvisoError, EncabezadoPagina, SelectorExpiracion, Pill } from '../components/ui.jsx'
import { useToast } from '../components/Toast.jsx'
import { aInputFechaHora, aIsoLocal, atajosExpiracion, colorDe, cuando, dinero, parseMonto } from '../utils.js'

const MAX_FOTOS = 5
const CAMPOS_PASO_1 = ['titulo', 'categoriaId', 'descripcion']

export default function PublicacionForm() {
  const { id } = useParams()
  const editando = Boolean(id)
  const ir = useNavigate()
  const { mostrar } = useToast()

  const [paso, setPaso] = useState(1)
  const [categorias, setCategorias] = useState([])
  const [f, setF] = useState({
    titulo: '', categoriaId: '', descripcion: '', tipo: 'temporal',
    fechaExpiracion: aInputFechaHora(atajosExpiracion()[0].fecha),
    precio: '', precioDesde: false, cantidad: '', lugar: '', disponible: true,
  })
  const [original, setOriginal] = useState(null)
  const [existentes, setExistentes] = useState([])
  const [quitar, setQuitar] = useState([])
  const [nuevas, setNuevas] = useState([])
  const [errores, setErrores] = useState({})
  const [cargando, setCargando] = useState(editando)
  const [guardando, setGuardando] = useState(false)

  const cambiar = (campo, valor) => { setF((x) => ({ ...x, [campo]: valor })); setErrores((e) => ({ ...e, [campo]: undefined })) }

  useEffect(() => { api.categorias().then(setCategorias).catch(() => {}) }, [])
  useEffect(() => {
    if (!editando) return
    api.publicacion(id).then((p) => {
      setOriginal(p)
      setExistentes(p.imagenes)
      setF({
        titulo: p.titulo, categoriaId: p.categoriaId ?? '', descripcion: p.descripcion ?? '',
        tipo: p.temporal ? 'temporal' : 'permanente',
        fechaExpiracion: p.fechaExpiracion ? aInputFechaHora(p.fechaExpiracion) : aInputFechaHora(atajosExpiracion()[0].fecha),
        precio: p.precio ?? '', precioDesde: p.precioDesde, cantidad: p.cantidad ?? '', lugar: p.lugar ?? '', disponible: p.disponible,
      })
    }).catch((e) => { mostrar(e.message, 'error'); ir('/') }).finally(() => setCargando(false))
  }, [id, editando, ir, mostrar])

  // Vistas previas de las fotos nuevas (se liberan al salir)
  useEffect(() => () => nuevas.forEach((n) => URL.revokeObjectURL(n.url)), [nuevas])

  const fotosVisibles = existentes.filter((x) => !quitar.includes(x.id))
  const totalFotos = fotosVisibles.length + nuevas.length

  const agregarFotos = (e) => {
    const archivos = Array.from(e.target.files || [])
    e.target.value = ''
    const permitidos = archivos.slice(0, MAX_FOTOS - totalFotos)
    if (archivos.length > permitidos.length) mostrar(`Cada publicación puede tener máximo ${MAX_FOTOS} fotos`, 'error')
    setNuevas((n) => [...n, ...permitidos.map((archivo) => ({ archivo, url: URL.createObjectURL(archivo) }))])
  }

  const validarPaso1 = () => {
    const e = {}
    if (!f.titulo.trim()) e.titulo = 'Escribe un título para la publicación'
    else if (f.titulo.trim().length > 150) e.titulo = 'El título no puede pasar de 150 caracteres'
    if (!f.categoriaId) e.categoriaId = 'Selecciona una categoría'
    return e
  }
  const validarPaso2 = () => {
    const e = {}
    if (f.tipo === 'temporal') {
      const sinCambio = original?.fechaExpiracion && aInputFechaHora(original.fechaExpiracion) === f.fechaExpiracion
      if (!f.fechaExpiracion) e.fechaExpiracion = 'Elige cuándo se oculta'
      else if (!sinCambio && new Date(f.fechaExpiracion) <= new Date()) e.fechaExpiracion = 'La fecha debe ser posterior a este momento'
    }
    if (String(f.precio).trim() !== '' && Number.isNaN(parseMonto(f.precio))) e.precio = 'Ingresa un precio válido'
    if (String(f.cantidad).trim() !== '' && !/^\d+$/.test(String(f.cantidad).trim())) e.cantidad = 'Ingresa una cantidad válida'
    if (f.lugar.length > 255) e.lugar = 'El lugar no puede pasar de 255 caracteres'
    return e
  }

  const siguiente = () => {
    const e = validarPaso1()
    setErrores(e)
    if (Object.keys(e).length === 0) setPaso(2)
  }

  const guardar = async () => {
    const e1 = validarPaso1()
    const e2 = validarPaso2()
    const todos = { ...e1, ...e2 }
    setErrores(todos)
    if (Object.keys(e1).length) { setPaso(1); return }
    if (Object.keys(e2).length) return

    const datos = {
      titulo: f.titulo.trim(),
      descripcion: f.descripcion.trim() || null,
      categoriaId: Number(f.categoriaId),
      fechaExpiracion: f.tipo === 'temporal' ? aIsoLocal(new Date(f.fechaExpiracion)) : null,
      precio: String(f.precio).trim() === '' ? null : parseMonto(f.precio),
      precioDesde: f.precioDesde,
      cantidad: String(f.cantidad).trim() === '' ? null : Number(f.cantidad),
      lugar: f.lugar.trim() || null,
      disponible: f.disponible,
    }

    setGuardando(true)
    let guardada
    try {
      guardada = editando ? await api.actualizarPublicacion(id, datos) : await api.crearPublicacion(datos)
    } catch (err) {
      setGuardando(false)
      if (err.errores && Object.keys(err.errores).length) {
        setErrores(err.errores)
        if (CAMPOS_PASO_1.some((c) => err.errores[c])) setPaso(1)
      } else mostrar(err.message, 'error')
      return
    }
    try {
      for (const imagenId of quitar) await api.eliminarImagen(guardada.id, imagenId)
      if (nuevas.length) await api.subirImagenes(guardada.id, nuevas.map((n) => n.archivo))
    } catch (err) {
      mostrar(`La publicación se guardó, pero hubo un problema con las fotos: ${err.message}`, 'error')
      ir('/')
      return
    }
    mostrar(editando ? 'Publicación actualizada correctamente' : 'Publicación creada correctamente')
    ir('/')
  }

  const hayErrores = Object.values(errores).some(Boolean)
  const categoria = categorias.find((c) => String(c.id) === String(f.categoriaId))
  const vistaPrevia = useMemo(() => ({
    titulo: f.titulo.trim() || 'Título de tu publicación',
    precio: String(f.precio).trim() !== '' && !Number.isNaN(parseMonto(f.precio)) ? `${f.precioDesde ? 'Desde ' : ''}${dinero(parseMonto(f.precio))}` : '',
    foto: nuevas[0]?.url || fotosVisibles[0]?.ruta || null,
  }), [f.titulo, f.precio, f.precioDesde, nuevas, fotosVisibles])

  if (cargando) return <div className="cargando-pagina">Cargando…</div>

  return (
    <>
      <EncabezadoPagina titulo={editando ? 'Editar publicación' : 'Nueva publicación'} regresarA="/" />
      <div className="formulario-pagina">
        <form className="formulario-tarjeta" onSubmit={(e) => e.preventDefault()} noValidate>
          <Pasos actual={paso} etiqueta={paso === 1 ? 'Contenido' : 'Precio y disponibilidad'} />
          {hayErrores && <AvisoError>Revisa los campos marcados en rojo</AvisoError>}

          {paso === 1 && (
            <>
              <Campo etiqueta="Título" error={errores.titulo}>
                <input value={f.titulo} onChange={(e) => cambiar('titulo', e.target.value)} placeholder="Ej. Pay tortuga" />
              </Campo>
              <Campo etiqueta="Categoría" error={errores.categoriaId}>
                <select value={f.categoriaId} onChange={(e) => cambiar('categoriaId', e.target.value)}>
                  <option value="">Elige una categoría</option>
                  {categorias.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
                </select>
              </Campo>
              <Campo etiqueta="Descripción" error={errores.descripcion}>
                <textarea rows={4} value={f.descripcion} onChange={(e) => cambiar('descripcion', e.target.value)} placeholder="Sabor, tamaño, de qué está hecho…" />
              </Campo>
              <div>
                <div className="campo-etiqueta">Fotos (máx. {MAX_FOTOS})</div>
                <div className="fotos-fila">
                  {fotosVisibles.map((x) => (
                    <div className="foto-mini" key={`e${x.id}`}>
                      <img src={x.ruta} alt="" />
                      <button type="button" aria-label="Quitar foto" onClick={() => setQuitar((q) => [...q, x.id])}><Icon name="x" size={16} /></button>
                    </div>
                  ))}
                  {nuevas.map((n, i) => (
                    <div className="foto-mini" key={n.url}>
                      <img src={n.url} alt="" />
                      <button type="button" aria-label="Quitar foto" onClick={() => setNuevas((a) => a.filter((_, k) => k !== i))}><Icon name="x" size={16} /></button>
                    </div>
                  ))}
                  {totalFotos < MAX_FOTOS && (
                    <label className="foto-agregar">
                      <Icon name="plus" size={28} color="var(--gold)" />
                      <input type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={agregarFotos} />
                    </label>
                  )}
                </div>
              </div>
              <div className="formulario-botones">
                <button className="btn btn-cafe" onClick={siguiente}>Siguiente</button>
              </div>
            </>
          )}

          {paso === 2 && (
            <>
              <div>
                <div className="campo-etiqueta">Duración</div>
                <Selector valor={f.tipo} onCambio={(v) => cambiar('tipo', v)}
                  opciones={[{ valor: 'temporal', etiqueta: 'Temporal' }, { valor: 'permanente', etiqueta: 'Permanente' }]} />
              </div>
              {f.tipo === 'temporal' && (
                <div>
                  <div className="campo-etiqueta">Se oculta el</div>
                  <SelectorExpiracion valor={f.fechaExpiracion} onCambio={(v) => cambiar('fechaExpiracion', v)} error={errores.fechaExpiracion} />
                </div>
              )}
              <div className="dos-columnas">
                <Campo etiqueta="Precio" error={errores.precio}>
                  <input inputMode="decimal" value={f.precio} onChange={(e) => cambiar('precio', e.target.value)} placeholder="$0.00" />
                </Campo>
                <Campo etiqueta="Cantidad" error={errores.cantidad}>
                  <input inputMode="numeric" value={f.cantidad} onChange={(e) => cambiar('cantidad', e.target.value)} placeholder="Ej. 8" />
                </Campo>
              </div>
              <Interruptor activo={f.precioDesde} onCambio={(v) => cambiar('precioDesde', v)} etiqueta='Mostrar precio como "desde"' />
              <Campo etiqueta="Lugar de entrega o venta" error={errores.lugar}>
                <input value={f.lugar} onChange={(e) => cambiar('lugar', e.target.value)} placeholder="Entrega en zona centro · Venta: x lugar" />
              </Campo>
              <div>
                <div className="campo-etiqueta">Estado</div>
                <Selector valor={f.disponible ? 'si' : 'no'} onCambio={(v) => cambiar('disponible', v === 'si')}
                  opciones={[{ valor: 'si', etiqueta: 'Disponible' }, { valor: 'no', etiqueta: 'Agotado' }]} />
              </div>
              {f.tipo === 'temporal' && f.fechaExpiracion && !errores.fechaExpiracion && (
                <div className="nota"><Icon name="bulb" size={22} color="var(--gold)" />
                  <span>Se ocultará {cuando(f.fechaExpiracion)}. Después podrás republicarla desde “Ocultas”.</span></div>
              )}
              <div className="formulario-botones">
                <button className="btn btn-claro" onClick={() => setPaso(1)} disabled={guardando}>Atrás</button>
                <button className="btn btn-cafe" onClick={guardar} disabled={guardando}>
                  {guardando ? 'Guardando…' : editando ? 'Guardar cambios' : 'Publicar'}
                </button>
              </div>
            </>
          )}
        </form>

        {/* Escritorio: así se verá para los clientes */}
        <aside className="lateral-derecho">
          <h3>Así se verá para tus clientes</h3>
          <div className="tarjeta vista-previa">
            {vistaPrevia.foto
              ? <img className="foto" style={{ height: 130 }} src={vistaPrevia.foto} alt="" />
              : <div className="foto foto-vacia" style={{ height: 130, background: colorDe(vistaPrevia.titulo) }}><span>{vistaPrevia.titulo}</span></div>}
            <div className="tarjeta-cuerpo">
              <div className="tarjeta-tags">
                {categoria && <Pill tipo="oro">{categoria.nombre}</Pill>}
                {f.tipo === 'temporal' && <Pill tipo="rosa">Temporal</Pill>}
              </div>
              <div className="tarjeta-titulo"><h3>{vistaPrevia.titulo}</h3><span className="precio">{vistaPrevia.precio}</span></div>
              {f.lugar.trim() && <div className="tarjeta-info"><Icon name="pin" size={16} color="var(--gold)" /><span>{f.lugar}</span></div>}
              {f.tipo === 'temporal' && f.fechaExpiracion && <div className="tarjeta-info"><Icon name="clock" size={16} color="var(--gold)" /><span>Disponible hasta {cuando(f.fechaExpiracion)}</span></div>}
              <button type="button" className="btn btn-cafe btn-sm" tabIndex={-1}>Me interesa</button>
            </div>
          </div>
          <div className="nota nota-vertical">
            <div className="nota-titulo"><Icon name="bulb" size={20} color="var(--gold)" />Consejos</div>
            <p>• Usa fotos claras y bien iluminadas del postre.</p>
            <p>• Las publicaciones temporales se ocultan solas al vencer.</p>
            <p>• El precio es opcional: úsalo “desde” para menús.</p>
            <p>• Si tu producto se acaba, márcalo como agotado en lugar de borrarlo.</p>
          </div>
        </aside>
      </div>
    </>
  )
}
