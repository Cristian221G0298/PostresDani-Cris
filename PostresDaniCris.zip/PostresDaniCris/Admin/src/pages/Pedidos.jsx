import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import { EncabezadoPagina, Pill } from '../components/ui.jsx'
import { ConfirmarEliminar } from '../components/Modal.jsx'
import { useToast } from '../components/Toast.jsx'
import { cuando, diaNumero, diaSemana, dinero, fechaCorta, fechaDiaMes, horaCorta, mesCorto, mismoDia } from '../utils.js'

const TABS = [{ id: 1, etiqueta: 'Próximos' }, { id: 2, etiqueta: 'Entregados' }, { id: 3, etiqueta: 'Cancelados' }]
const plural = (n, uno, varios) => `${n} ${n === 1 ? uno : varios}`

function TarjetaPedido({ p, hoy, abierto, onAbrir, menuAbierto, onMenu, onAccion }) {
  const entrega = new Date(p.fechaEntrega)
  return (
    <article className={`pedido ${hoy ? 'hoy' : ''}`}>
      <div className="pedido-fecha">
        <span>{diaSemana(entrega)}</span>
        <strong>{diaNumero(entrega)}</strong>
        <span>{mesCorto(entrega)}</span>
        <em>{horaCorta(entrega)}</em>
      </div>
      <div className="pedido-cuerpo">
        <div className="pedido-fila">
          <h3>{p.aNombreDe}</h3>
          <div className="kebab-wrap">
            <button className="kebab" onClick={() => onMenu(menuAbierto ? null : p.id)} aria-label="Opciones del pedido"><Icon name="more" size={20} color="var(--soft)" /></button>
            {menuAbierto && (
              <>
                <div className="menu-fondo" onClick={() => onMenu(null)} />
                <div className="menu-opciones" role="menu">
                  <div className="menu-cabecera"><strong>{p.aNombreDe}</strong><span>Entrega {cuando(entrega)}</span></div>
                  <button onClick={() => onAccion('editar', p)}><Icon name="edit" size={20} />Editar pedido</button>
                  {p.estadoId === 1 ? (
                    <>
                      <button className="verde" onClick={() => onAccion('entregar', p)}><Icon name="check" size={20} />Marcar como entregado</button>
                      <button className="gris" onClick={() => onAccion('cancelar', p)}><Icon name="x" size={20} />Cancelar pedido</button>
                    </>
                  ) : (
                    <button onClick={() => onAccion('reabrir', p)}><Icon name="redo" size={20} />Volver a próximos</button>
                  )}
                  <button className="rojo" onClick={() => onAccion('eliminar', p)}><Icon name="trash" size={20} />Eliminar pedido</button>
                </div>
              </>
            )}
          </div>
        </div>
        <div className="tarjeta-info"><Icon name="pin" size={16} color="var(--gold)" /><span>{p.lugarEntrega}</span></div>
        <div className="pedido-pills">
          <Pill tipo="verde">Anticipo {dinero(p.anticipo)}</Pill>
          {p.resta > 0 ? <Pill tipo="oro">Resta {dinero(p.resta)}</Pill> : <Pill tipo="verde">Liquidado</Pill>}
          {p.estadoId === 2 && <Pill tipo="verde">Entregado</Pill>}
          {p.estadoId === 3 && <Pill tipo="rojo">Cancelado</Pill>}
        </div>
        {abierto && (
          <div className="pedido-detalles">
            <small>DETALLES DEL PEDIDO</small>
            <p>{p.detallesPedido}</p>
            <small className="suave">Agendado: {fechaCorta(p.fechaAgendado)}</small>
          </div>
        )}
        <button className="enlace-detalles" onClick={onAbrir}>
          {abierto ? 'Ocultar detalles' : 'Ver detalles'}<Icon name={abierto ? 'up' : 'down'} size={14} color="var(--gold)" grosor={2.6} />
        </button>
      </div>
    </article>
  )
}

export default function Pedidos() {
  const ir = useNavigate()
  const { mostrar } = useToast()
  const [tab, setTab] = useState(1)
  const [lista, setLista] = useState(null)
  const [resumen, setResumen] = useState(null)
  const [error, setError] = useState('')
  const [abiertos, setAbiertos] = useState({})
  const [menu, setMenu] = useState(null)
  const [porEliminar, setPorEliminar] = useState(null)

  const cargar = useCallback(() => {
    Promise.all([api.pedidos(tab), api.resumenPedidos(tab)])
      .then(([l, r]) => { setLista(l); setResumen(r); setError('') })
      .catch((e) => setError(e.message))
  }, [tab])
  useEffect(() => { setLista(null); cargar() }, [cargar])

  const cambiarEstado = async (p, estadoId, mensaje) => {
    try { await api.cambiarEstadoPedido(p.id, estadoId); mostrar(mensaje); cargar() }
    catch (e) { mostrar(e.message, 'error') }
  }

  const accion = (tipo, p) => {
    setMenu(null)
    if (tipo === 'editar') ir(`/pedidos/${p.id}/editar`)
    else if (tipo === 'entregar') cambiarEstado(p, 2, 'Pedido marcado como entregado')
    else if (tipo === 'cancelar') cambiarEstado(p, 3, 'Pedido cancelado')
    else if (tipo === 'reabrir') cambiarEstado(p, 1, 'El pedido volvió a próximos')
    else if (tipo === 'eliminar') setPorEliminar(p)
  }

  const eliminar = async () => {
    try { await api.eliminarPedido(porEliminar.id); mostrar('Pedido eliminado correctamente') }
    catch (e) { mostrar(e.message, 'error') }
    setPorEliminar(null)
    cargar()
  }

  const hoy = new Date()
  const esHoy = (p) => tab === 1 && mismoDia(new Date(p.fechaEntrega), hoy)
  const deHoy = (lista || []).filter(esHoy)
  const resto = (lista || []).filter((p) => !esHoy(p))
  const etiquetaResto = tab === 1 ? 'PRÓXIMOS' : tab === 2 ? 'ENTREGADOS' : 'CANCELADOS'

  const totalMovido = resumen ? resumen.porCobrar + resumen.anticiposRecibidos : 0
  const estadisticas = !resumen ? [] : tab === 1
    ? [[dinero(resumen.porCobrar), 'Por cobrar', 'wallet', true], [dinero(resumen.anticiposRecibidos), 'Anticipos recibidos', 'check'], [String(resumen.cantidad), 'Pedidos próximos', 'cal']]
    : tab === 2
      ? [[dinero(totalMovido), 'Cobrado', 'wallet', true], [dinero(resumen.anticiposRecibidos), 'Anticipos recibidos', 'check'], [String(resumen.cantidad), 'Pedidos entregados', 'cal']]
      : [[dinero(totalMovido), 'Monto cancelado', 'wallet', true], [dinero(resumen.anticiposRecibidos), 'Anticipo registrado', 'check'], [String(resumen.cantidad), 'Pedidos cancelados', 'cal']]
  const tituloLado = tab === 1 ? 'Próximas entregas' : tab === 2 ? 'Entregas realizadas' : 'Pedidos cancelados'

  const render = (p) => (
    <TarjetaPedido key={p.id} p={p} hoy={esHoy(p)}
      abierto={Boolean(abiertos[p.id])} onAbrir={() => setAbiertos((a) => ({ ...a, [p.id]: !a[p.id] }))}
      menuAbierto={menu === p.id} onMenu={setMenu} onAccion={accion} />
  )

  return (
    <>
      <EncabezadoPagina titulo="Agenda de pedidos" regresarA="/">
        <Link to="/pedidos/nuevo" className="btn btn-oro btn-redondo solo-escritorio"><Icon name="plus" size={18} />Nuevo pedido</Link>
      </EncabezadoPagina>

      <div className="barra-pedidos">
        <div className="selector selector-pedidos">
          {TABS.map((t) => <button key={t.id} className={tab === t.id ? 'activo' : ''} onClick={() => { setTab(t.id); setMenu(null) }}>{t.etiqueta}</button>)}
        </div>
        {resumen && (
          <div className="pills-resumen">
            <Pill tipo="blanco">{plural(resumen.cantidad, tab === 1 ? 'pedido próximo' : tab === 2 ? 'pedido entregado' : 'pedido cancelado', tab === 1 ? 'pedidos próximos' : tab === 2 ? 'pedidos entregados' : 'pedidos cancelados')}</Pill>
            {tab === 1 && <Pill tipo="oro">Por cobrar {dinero(resumen.porCobrar)}</Pill>}
          </div>
        )}
      </div>

      <div className="pedidos-cuerpo">
        <div className="pedidos-lista">
          {error && <div className="vacio">{error}</div>}
          {lista && lista.length === 0 && !error && (
            <div className="vacio">
              <Icon name="cal" size={36} color="var(--gold)" />
              <h3>No hay pedidos {tab === 1 ? 'próximos' : tab === 2 ? 'entregados' : 'cancelados'}</h3>
              {tab === 1 && <p>Agrega el primero con el botón “Nuevo pedido”.</p>}
            </div>
          )}
          {deHoy.length > 0 && <><div className="grupo">HOY</div>{deHoy.map(render)}</>}
          {resto.length > 0 && <><div className="grupo">{etiquetaResto}</div>{resto.map(render)}</>}
        </div>

        <aside className="pedidos-lado">
          <h3>Resumen</h3>
          {estadisticas.map(([valor, etiqueta, icono, destacado]) => (
            <div key={etiqueta} className={`estadistica ${destacado ? 'destacada' : ''}`}>
              <span className="estadistica-icono"><Icon name={icono} size={24} color="var(--gold)" /></span>
              <div><strong>{valor}</strong><span>{etiqueta}</span></div>
            </div>
          ))}
          <div className="lado-lista">
            <h4>{tituloLado}</h4>
            {(lista || []).slice(0, 6).map((p, i) => (
              <div className="lado-item" key={p.id}>
                <span className={`lado-dia ${tab === 1 && i === 0 && mismoDia(new Date(p.fechaEntrega), hoy) ? 'hoy' : ''}`}>{diaNumero(new Date(p.fechaEntrega))}</span>
                <div><strong>{p.aNombreDe}</strong><small>{diaSemana(new Date(p.fechaEntrega))} {fechaDiaMes(new Date(p.fechaEntrega)).toUpperCase()} · {horaCorta(new Date(p.fechaEntrega))}</small></div>
              </div>
            ))}
            {lista && lista.length === 0 && <small className="suave">Sin pedidos por ahora.</small>}
          </div>
        </aside>
      </div>

      <Link to="/pedidos/nuevo" className="fab solo-movil"><Icon name="plus" size={20} />Nuevo pedido</Link>

      {porEliminar && (
        <ConfirmarEliminar titulo="¿Eliminar pedido?"
          mensaje={`Se eliminará el pedido de ${porEliminar.aNombreDe}. Esta acción no se puede deshacer.`}
          onConfirmar={eliminar} onCancelar={() => setPorEliminar(null)} />
      )}
    </>
  )
}
