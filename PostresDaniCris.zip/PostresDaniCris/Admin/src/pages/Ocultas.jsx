import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import { EncabezadoPagina, TarjetaPublicacion, SelectorExpiracion } from '../components/ui.jsx'
import { ConfirmarEliminar, Modal } from '../components/Modal.jsx'
import { useToast } from '../components/Toast.jsx'
import { atajosExpiracion, aInputFechaHora, aIsoLocal } from '../utils.js'

export default function Ocultas() {
  const ir = useNavigate()
  const { mostrar } = useToast()
  const [lista, setLista] = useState(null)
  const [error, setError] = useState('')
  const [porEliminar, setPorEliminar] = useState(null)
  const [porRepublicar, setPorRepublicar] = useState(null)
  const [fecha, setFecha] = useState('')
  const [errorFecha, setErrorFecha] = useState('')
  const [trabajando, setTrabajando] = useState(false)

  const cargar = useCallback(() => api.ocultas().then(setLista).catch((e) => setError(e.message)), [])
  useEffect(() => { cargar() }, [cargar])

  const abrirRepublicar = (p) => {
    setPorRepublicar(p)
    setFecha(aInputFechaHora(atajosExpiracion()[0].fecha))
    setErrorFecha('')
  }

  const republicar = async () => {
    if (!fecha) { setErrorFecha('Elige cuándo se oculta'); return }
    if (new Date(fecha) <= new Date()) { setErrorFecha('La fecha debe ser posterior a este momento'); return }
    setTrabajando(true)
    try {
      await api.republicar(porRepublicar.id, aIsoLocal(new Date(fecha)))
      mostrar('Publicación republicada correctamente')
      ir('/')
    } catch (e) {
      setErrorFecha(e.errores?.fechaExpiracion || e.message)
    } finally {
      setTrabajando(false)
    }
  }

  const eliminar = async () => {
    try {
      await api.eliminarPublicacion(porEliminar.id)
      mostrar('Publicación eliminada correctamente')
    } catch (e) {
      mostrar(e.message, 'error')
    }
    setPorEliminar(null)
    cargar()
  }

  return (
    <>
      <EncabezadoPagina titulo="Publicaciones ocultas" regresarA="/" />
      <p className="texto-suave">Aquí quedan las temporales que ya expiraron, por si quieres volver a publicarlas.</p>

      {error && <div className="vacio">{error}</div>}
      {lista && lista.length === 0 && (
        <div className="vacio">
          <Icon name="eyeoff" size={36} color="var(--gold)" />
          <h3>No hay publicaciones ocultas</h3>
          <p>Las temporales que venzan aparecerán aquí.</p>
        </div>
      )}
      {lista && lista.length > 0 && (
        <div className="rejilla">
          {lista.map((p) => (
            <TarjetaPublicacion key={p.id} p={p} oculta onRepublicar={() => abrirRepublicar(p)} onEliminar={() => setPorEliminar(p)} />
          ))}
        </div>
      )}
      <div className="nota solo-escritorio">
        <Icon name="bulb" size={22} color="var(--gold)" />
        <span>Al republicar eliges cuánto tiempo estará visible (hoy, 24 h o 48 h) y la publicación vuelve a mostrarse al público de inmediato.</span>
      </div>

      {porRepublicar && (
        <Modal onCerrar={() => setPorRepublicar(null)} ancho={520} alFondo>
          <h2 className="modal-titulo">Republicar publicación</h2>
          <p className="modal-sub">“{porRepublicar.titulo}”</p>
          <div className="campo-etiqueta">Se oculta el</div>
          <SelectorExpiracion valor={fecha} onCambio={(v) => { setFecha(v); setErrorFecha('') }} error={errorFecha} />
          <p className="modal-texto">La publicación volverá a mostrarse al público de inmediato.</p>
          <div className="modal-botones">
            <button className="btn btn-claro" onClick={() => setPorRepublicar(null)}>Cancelar</button>
            <button className="btn btn-cafe" onClick={republicar} disabled={trabajando}>{trabajando ? 'Republicando…' : 'Republicar'}</button>
          </div>
        </Modal>
      )}
      {porEliminar && (
        <ConfirmarEliminar titulo="¿Eliminar publicación?"
          mensaje={`Se eliminará “${porEliminar.titulo}” y sus fotos. Esta acción no se puede deshacer.`}
          onConfirmar={eliminar} onCancelar={() => setPorEliminar(null)} />
      )}
    </>
  )
}
