import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// En desarrollo, el front llama a /api y /uploads y Vite los reenvía a la API.
// Así el navegador ve un solo origen y la cookie de sesión funciona sin configurar CORS.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const api = env.API_URL
  if (!api && mode === 'development') {
    console.warn('\n[Admin] Falta API_URL en el archivo .env (copia .env.example como .env y escribe la dirección de la API).\n')
  }
  const proxy = api
    ? {
        '/api': { target: api, changeOrigin: true, secure: false },
        '/uploads': { target: api, changeOrigin: true, secure: false },
      }
    : undefined
  return {
    plugins: [react()],
    server: { proxy },
  }
})
