-- =====================================================================
--  Postres Dani & Cris — Base de datos (MySQL 8)
--  Si IONOS ya te da una base creada, comenta estas dos líneas.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS postres_dani_cris
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE postres_dani_cris;

-- Administradores (único login, sin registro público)
CREATE TABLE administradores (
  id              INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  usuario         VARCHAR(60) NOT NULL UNIQUE,
  contrasena_hash CHAR(64)    NOT NULL   -- SHA256 en hexadecimal
);

-- Categorías
CREATE TABLE categorias (
  id     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL UNIQUE
);

-- Publicaciones
-- fecha_expiracion NULL  = permanente
-- fecha_expiracion con fecha = temporal (se oculta al vencer)
-- categoria_id NULL = sin categoría
CREATE TABLE publicaciones (
  id                INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  titulo            VARCHAR(150) NOT NULL,
  descripcion       TEXT NULL,
  categoria_id      INT NULL,
  fecha_publicacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_expiracion  DATETIME NULL,
  precio            DECIMAL(10,2) NULL,
  precio_desde      TINYINT(1) NOT NULL DEFAULT 0,
  cantidad          INT NULL,
  lugar             VARCHAR(255) NULL,
  disponible        TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (categoria_id) REFERENCES categorias (id) ON DELETE SET NULL
);

-- Fotos de las publicaciones (la API limita a 5 por publicación)
CREATE TABLE publicacion_imagenes (
  id             INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  publicacion_id INT NOT NULL,
  ruta           VARCHAR(500) NOT NULL,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones (id) ON DELETE CASCADE
);

-- Estados de los pedidos
CREATE TABLE estados (
  id     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(30) NOT NULL UNIQUE
);

-- Agenda de pedidos (solo admin). Se ordena por fecha_entrega.
-- estado_id: 1 = Próximo, 2 = Entregado, 3 = Cancelado
CREATE TABLE pedidos (
  id               INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  a_nombre_de      VARCHAR(120) NOT NULL,
  detalles_pedido  TEXT NOT NULL,
  anticipo         DECIMAL(10,2) NOT NULL DEFAULT 0,
  resta            DECIMAL(10,2) NOT NULL DEFAULT 0,
  fecha_agendado   DATE NOT NULL,
  fecha_entrega    DATETIME NOT NULL,
  lugar_entrega    VARCHAR(255) NOT NULL,
  estado_id        INT NOT NULL DEFAULT 1,
  FOREIGN KEY (estado_id) REFERENCES estados (id)
);

-- Datos de referencia que la aplicación necesita para funcionar
INSERT INTO estados (id, nombre) VALUES
  (1, 'Próximo'),
  (2, 'Entregado'),
  (3, 'Cancelado');

INSERT INTO categorias (nombre) VALUES
  ('Disponible hoy'),
  ('Menú de pedidos'),
  ('Promociones'),
  ('Nuevos productos'),
  ('Avisos');

-- Agregar un administrador manualmente (cambia usuario y contraseña):
-- INSERT INTO administradores (usuario, contrasena_hash)
-- VALUES ('dani', SHA2('CAMBIA_ESTA_CONTRASENA', 256));
