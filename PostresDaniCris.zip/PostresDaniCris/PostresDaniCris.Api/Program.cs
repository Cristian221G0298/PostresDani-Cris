using FluentValidation;
using Microsoft.AspNetCore.Authentication.Cookies;
using PostresDaniCris.Api.Helpers;
using PostresDaniCris.Api.Mappers;
using PostresDaniCris.Api.Repositories;
using PostresDaniCris.Api.Services;
using PostresDaniCris.Api.Validators;

var builder = WebApplication.CreateBuilder(args);

// Dapper: a_nombre_de (MySQL) -> ANombreDe (C#)
Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

// ---------- Base de datos (la conexión se configura en appsettings.json) ----------
var cadena = builder.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("Falta ConnectionStrings:Default en appsettings.json");
builder.Services.AddSingleton<IDbConnectionFactory>(new MySqlConnectionFactory(cadena));
builder.Services.AddSingleton<IReloj, Reloj>();

// ---------- Repositorios ----------
builder.Services.AddScoped<IAdministradorRepository, AdministradorRepository>();
builder.Services.AddScoped<ICategoriaRepository, CategoriaRepository>();
builder.Services.AddScoped<IEstadoRepository, EstadoRepository>();
builder.Services.AddScoped<IPublicacionRepository, PublicacionRepository>();
builder.Services.AddScoped<IPublicacionImagenRepository, PublicacionImagenRepository>();
builder.Services.AddScoped<IPedidoRepository, PedidoRepository>();

// ---------- Servicios ----------
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ICatalogoService, CatalogoService>();
builder.Services.AddScoped<IPublicacionService, PublicacionService>();
builder.Services.AddScoped<IPedidoService, PedidoService>();

// ---------- AutoMapper y FluentValidation ----------
builder.Services.AddAutoMapper(typeof(MappingProfile));
builder.Services.AddValidatorsFromAssemblyContaining<LoginRequestValidator>();

// ---------- Sesión del administrador: cookie (sin JWT) ----------
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(opciones =>
    {
        opciones.Cookie.Name = "pdc_admin";
        opciones.Cookie.HttpOnly = true;
        opciones.Cookie.SameSite = SameSiteMode.Lax;
        opciones.ExpireTimeSpan = TimeSpan.FromHours(8);
        opciones.SlidingExpiration = true;
        // Es una API: en vez de redirigir al login se responde 401 / 403
        opciones.Events.OnRedirectToLogin = contexto =>
        {
            contexto.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return Task.CompletedTask;
        };
        opciones.Events.OnRedirectToAccessDenied = contexto =>
        {
            contexto.Response.StatusCode = StatusCodes.Status403Forbidden;
            return Task.CompletedTask;
        };
    });
builder.Services.AddAuthorization();

// ---------- CORS (solo si el front corre en otro origen; ver Cors:Origenes en appsettings.json) ----------
var origenes = builder.Configuration.GetSection("Cors:Origenes").Get<string[]>() ?? Array.Empty<string>();
if (origenes.Length > 0)
{
    builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
        p.WithOrigins(origenes).AllowAnyHeader().AllowAnyMethod().AllowCredentials()));
}

builder.Services.AddControllers(o => o.Filters.Add<ValidationFilter>());

var app = builder.Build();

app.UseMiddleware<ManejadorErrores>();
app.UseStaticFiles();                   // fotos guardadas en wwwroot/uploads
if (origenes.Length > 0) app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
