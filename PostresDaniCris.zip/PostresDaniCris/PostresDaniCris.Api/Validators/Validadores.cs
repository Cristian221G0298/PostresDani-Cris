using FluentValidation;
using PostresDaniCris.Api.DTOs;

namespace PostresDaniCris.Api.Validators;

public class LoginRequestValidator : AbstractValidator<LoginRequest>
{
    public LoginRequestValidator()
    {
        RuleFor(x => x.Usuario).NotEmpty().WithMessage("Escribe tu usuario");
        RuleFor(x => x.Contrasena).NotEmpty().WithMessage("Escribe tu contraseña");
    }
}

public class PublicacionRequestValidator : AbstractValidator<PublicacionRequest>
{
    public PublicacionRequestValidator()
    {
        RuleFor(x => x.Titulo).NotEmpty().WithMessage("Escribe un título para la publicación")
            .MaximumLength(150).WithMessage("El título no puede pasar de 150 caracteres");
        RuleFor(x => x.CategoriaId).NotNull().WithMessage("Selecciona una categoría");
        RuleFor(x => x.Precio).GreaterThanOrEqualTo(0).When(x => x.Precio.HasValue)
            .WithMessage("Ingresa un precio válido");
        RuleFor(x => x.Cantidad).GreaterThanOrEqualTo(0).When(x => x.Cantidad.HasValue)
            .WithMessage("Ingresa una cantidad válida");
        RuleFor(x => x.Lugar).MaximumLength(255).WithMessage("El lugar no puede pasar de 255 caracteres");
    }
}

public class RepublicarRequestValidator : AbstractValidator<RepublicarRequest>
{
    public RepublicarRequestValidator()
    {
        RuleFor(x => x.FechaExpiracion).GreaterThan(DateTime.MinValue).WithMessage("Elige cuándo se oculta");
    }
}

public class PedidoRequestValidator : AbstractValidator<PedidoRequest>
{
    public PedidoRequestValidator()
    {
        RuleFor(x => x.ANombreDe).NotEmpty().WithMessage("Escribe a nombre de quién es el pedido")
            .MaximumLength(120).WithMessage("El nombre no puede pasar de 120 caracteres");
        RuleFor(x => x.DetallesPedido).NotEmpty().WithMessage("Describe el pedido");
        RuleFor(x => x.Anticipo).GreaterThanOrEqualTo(0).WithMessage("Ingresa un monto válido");
        RuleFor(x => x.Resta).GreaterThanOrEqualTo(0).WithMessage("Ingresa un monto válido");
        RuleFor(x => x.FechaAgendado).GreaterThan(DateTime.MinValue).WithMessage("Indica la fecha en que se agendó");
        RuleFor(x => x.FechaEntrega).GreaterThan(DateTime.MinValue).WithMessage("Indica la fecha y hora de entrega");
        RuleFor(x => x.LugarEntrega).NotEmpty().WithMessage("Escribe el lugar de entrega")
            .MaximumLength(255).WithMessage("El lugar no puede pasar de 255 caracteres");
    }
}

public class CambiarEstadoRequestValidator : AbstractValidator<CambiarEstadoRequest>
{
    public CambiarEstadoRequestValidator()
    {
        RuleFor(x => x.EstadoId).InclusiveBetween(1, 3).WithMessage("Estado no válido");
    }
}
