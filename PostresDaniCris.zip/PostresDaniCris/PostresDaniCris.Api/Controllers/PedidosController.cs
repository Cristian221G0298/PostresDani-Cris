using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PostresDaniCris.Api.DTOs;
using PostresDaniCris.Api.Services;

namespace PostresDaniCris.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/pedidos")]
public class PedidosController : ControllerBase
{
    private readonly IPedidoService _servicio;
    public PedidosController(IPedidoService servicio) => _servicio = servicio;

    /// <summary>Pedidos de un estado (1 Próximo, 2 Entregado, 3 Cancelado). Los próximos van por cercanía de entrega.</summary>
    [HttpGet]
    public async Task<IActionResult> Listar([FromQuery] int estadoId = 1) => Ok(await _servicio.ListarAsync(estadoId));

    [HttpGet("resumen")]
    public async Task<IActionResult> Resumen([FromQuery] int estadoId = 1) => Ok(await _servicio.ResumenAsync(estadoId));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Obtener(int id) => Ok(await _servicio.ObtenerAsync(id));

    [HttpPost]
    public async Task<IActionResult> Crear([FromBody] PedidoRequest solicitud)
    {
        var creado = await _servicio.CrearAsync(solicitud);
        return CreatedAtAction(nameof(Obtener), new { id = creado.Id }, creado);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Actualizar(int id, [FromBody] PedidoRequest solicitud) =>
        Ok(await _servicio.ActualizarAsync(id, solicitud));

    [HttpPatch("{id:int}/estado")]
    public async Task<IActionResult> CambiarEstado(int id, [FromBody] CambiarEstadoRequest solicitud) =>
        Ok(await _servicio.CambiarEstadoAsync(id, solicitud.EstadoId));

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Eliminar(int id)
    {
        await _servicio.EliminarAsync(id);
        return NoContent();
    }
}
