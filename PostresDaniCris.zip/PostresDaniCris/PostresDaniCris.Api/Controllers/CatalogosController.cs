using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PostresDaniCris.Api.Services;

namespace PostresDaniCris.Api.Controllers;

[ApiController]
[Authorize]
[Route("api")]
public class CatalogosController : ControllerBase
{
    private readonly ICatalogoService _catalogos;
    public CatalogosController(ICatalogoService catalogos) => _catalogos = catalogos;

    [HttpGet("categorias")]
    public async Task<IActionResult> Categorias() => Ok(await _catalogos.CategoriasAsync());

    [HttpGet("estados")]
    public async Task<IActionResult> Estados() => Ok(await _catalogos.EstadosAsync());
}
