using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PostresDaniCris.Api.DTOs;
using PostresDaniCris.Api.Services;

namespace PostresDaniCris.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/publicaciones")]
public class PublicacionesController : ControllerBase
{
    private readonly IPublicacionService _servicio;
    public PublicacionesController(IPublicacionService servicio) => _servicio = servicio;

    /// <summary>Publicaciones vigentes (permanentes y temporales que no han vencido).</summary>
    [HttpGet]
    public async Task<IActionResult> Listar([FromQuery] string? buscar, [FromQuery] int? categoriaId) =>
        Ok(await _servicio.ListarActivasAsync(buscar, categoriaId));

    /// <summary>Temporales que ya vencieron.</summary>
    [HttpGet("ocultas")]
    public async Task<IActionResult> Ocultas() => Ok(await _servicio.ListarOcultasAsync());

    [HttpGet("resumen")]
    public async Task<IActionResult> Resumen() => Ok(await _servicio.ResumenAsync());

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Obtener(int id) => Ok(await _servicio.ObtenerAsync(id));

    [HttpPost]
    public async Task<IActionResult> Crear([FromBody] PublicacionRequest solicitud)
    {
        var creada = await _servicio.CrearAsync(solicitud);
        return CreatedAtAction(nameof(Obtener), new { id = creada.Id }, creada);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Actualizar(int id, [FromBody] PublicacionRequest solicitud) =>
        Ok(await _servicio.ActualizarAsync(id, solicitud));

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Eliminar(int id)
    {
        await _servicio.EliminarAsync(id);
        return NoContent();
    }

    [HttpPost("{id:int}/republicar")]
    public async Task<IActionResult> Republicar(int id, [FromBody] RepublicarRequest solicitud) =>
        Ok(await _servicio.RepublicarAsync(id, solicitud.FechaExpiracion));

    [HttpPost("{id:int}/imagenes")]
    public async Task<IActionResult> SubirImagenes(int id, [FromForm] List<IFormFile> archivos) =>
        Ok(await _servicio.AgregarImagenesAsync(id, archivos));

    [HttpDelete("{id:int}/imagenes/{imagenId:int}")]
    public async Task<IActionResult> EliminarImagen(int id, int imagenId)
    {
        await _servicio.EliminarImagenAsync(id, imagenId);
        return NoContent();
    }
}
