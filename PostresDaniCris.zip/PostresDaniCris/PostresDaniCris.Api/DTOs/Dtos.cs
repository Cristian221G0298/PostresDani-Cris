namespace PostresDaniCris.Api.DTOs;

public class LoginRequest
{
    public string Usuario { get; set; } = "";
    public string Contrasena { get; set; } = "";
}

public class CategoriaDto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}

public class EstadoDto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}

public class ImagenDto
{
    public int Id { get; set; }
    public string Ruta { get; set; } = "";
}

public class PublicacionRequest
{
    public string Titulo { get; set; } = "";
    public string? Descripcion { get; set; }
    public int? CategoriaId { get; set; }
    /// <summary>Null = permanente. Con fecha = temporal (se oculta al vencer).</summary>
    public DateTime? FechaExpiracion { get; set; }
    public decimal? Precio { get; set; }
    public bool PrecioDesde { get; set; }
    public int? Cantidad { get; set; }
    public string? Lugar { get; set; }
    public bool Disponible { get; set; } = true;
}

public class PublicacionDto
{
    public int Id { get; set; }
    public string Titulo { get; set; } = "";
    public string? Descripcion { get; set; }
    public int? CategoriaId { get; set; }
    public string? CategoriaNombre { get; set; }
    public DateTime FechaPublicacion { get; set; }
    public DateTime? FechaExpiracion { get; set; }
    public bool Temporal { get; set; }
    public decimal? Precio { get; set; }
    public bool PrecioDesde { get; set; }
    public int? Cantidad { get; set; }
    public string? Lugar { get; set; }
    public bool Disponible { get; set; }
    public List<ImagenDto> Imagenes { get; set; } = new();
}

public class RepublicarRequest
{
    public DateTime FechaExpiracion { get; set; }
}

public class ResumenPublicacionesDto
{
    public int Activas { get; set; }
    public int Temporales { get; set; }
    public int Permanentes { get; set; }
    public int Ocultas { get; set; }
}

public class PedidoRequest
{
    public string ANombreDe { get; set; } = "";
    public string DetallesPedido { get; set; } = "";
    public decimal Anticipo { get; set; }
    public decimal Resta { get; set; }
    public DateTime FechaAgendado { get; set; }
    public DateTime FechaEntrega { get; set; }
    public string LugarEntrega { get; set; } = "";
}

public class PedidoDto
{
    public int Id { get; set; }
    public string ANombreDe { get; set; } = "";
    public string DetallesPedido { get; set; } = "";
    public decimal Anticipo { get; set; }
    public decimal Resta { get; set; }
    public DateTime FechaAgendado { get; set; }
    public DateTime FechaEntrega { get; set; }
    public string LugarEntrega { get; set; } = "";
    public int EstadoId { get; set; }
    public string? EstadoNombre { get; set; }
}

public class CambiarEstadoRequest
{
    public int EstadoId { get; set; }
}

public class ResumenPedidosDto
{
    public int Cantidad { get; set; }
    public decimal PorCobrar { get; set; }
    public decimal AnticiposRecibidos { get; set; }
}
