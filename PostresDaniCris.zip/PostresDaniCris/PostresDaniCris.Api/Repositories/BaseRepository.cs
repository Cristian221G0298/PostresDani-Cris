using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection;
using System.Text.RegularExpressions;
using Dapper;
using PostresDaniCris.Api.Helpers;

namespace PostresDaniCris.Api.Repositories;

public interface IRepository<T> where T : class
{
    Task<IEnumerable<T>> GetAllAsync();
    Task<T?> GetByIdAsync(int id);
    Task<int> InsertAsync(T entidad);
    Task<bool> UpdateAsync(T entidad);
    Task<bool> DeleteAsync(int id);
}

/// <summary>
/// Repositorio genérico: arma el SQL a partir de la entidad.
/// La tabla sale de [Table] y las columnas son el nombre de la propiedad en snake_case
/// (ANombreDe -> a_nombre_de). Lo marcado con [NotMapped] no se guarda.
/// </summary>
public abstract class BaseRepository<T> : IRepository<T> where T : class
{
    protected readonly IDbConnectionFactory Db;
    protected BaseRepository(IDbConnectionFactory db) => Db = db;

    protected static readonly string Tabla =
        typeof(T).GetCustomAttribute<TableAttribute>()?.Name
        ?? throw new InvalidOperationException($"{typeof(T).Name} necesita el atributo [Table]");

    private static readonly PropertyInfo[] Propiedades = typeof(T).GetProperties()
        .Where(p => p.CanRead && p.CanWrite && p.GetCustomAttribute<NotMappedAttribute>() is null)
        .ToArray();

    private static string Snake(string nombre) =>
        Regex.Replace(nombre, "(?<!^)([A-Z])", "_$1").ToLowerInvariant();

    public async Task<IEnumerable<T>> GetAllAsync()
    {
        using var conexion = Db.Create();
        return await conexion.QueryAsync<T>($"SELECT * FROM {Tabla}");
    }

    public async Task<T?> GetByIdAsync(int id)
    {
        using var conexion = Db.Create();
        return await conexion.QueryFirstOrDefaultAsync<T>($"SELECT * FROM {Tabla} WHERE id = @id", new { id });
    }

    public async Task<int> InsertAsync(T entidad)
    {
        var props = Propiedades.Where(p => p.Name != "Id").ToList();
        var columnas = string.Join(", ", props.Select(p => Snake(p.Name)));
        var valores = string.Join(", ", props.Select(p => "@" + p.Name));
        using var conexion = Db.Create();
        return await conexion.ExecuteScalarAsync<int>(
            $"INSERT INTO {Tabla} ({columnas}) VALUES ({valores}); SELECT LAST_INSERT_ID();", entidad);
    }

    public async Task<bool> UpdateAsync(T entidad)
    {
        var props = Propiedades.Where(p => p.Name != "Id").ToList();
        var asignaciones = string.Join(", ", props.Select(p => $"{Snake(p.Name)} = @{p.Name}"));
        using var conexion = Db.Create();
        return await conexion.ExecuteAsync($"UPDATE {Tabla} SET {asignaciones} WHERE id = @Id", entidad) > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        using var conexion = Db.Create();
        return await conexion.ExecuteAsync($"DELETE FROM {Tabla} WHERE id = @id", new { id }) > 0;
    }
}
