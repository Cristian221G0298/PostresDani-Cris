using Dapper;
using PostresDaniCris.Api.DTOs;
using PostresDaniCris.Api.Helpers;
using PostresDaniCris.Api.Models;

namespace PostresDaniCris.Api.Repositories;

// ---------- Administradores ----------
public interface IAdministradorRepository : IRepository<Administrador>
{
    Task<Administrador?> ObtenerPorUsuarioAsync(string usuario);
}

public class AdministradorRepository : BaseRepository<Administrador>, IAdministradorRepository
{
    public AdministradorRepository(IDbConnectionFactory db) : base(db) { }

    public async Task<Administrador?> ObtenerPorUsuarioAsync(string usuario)
    {
        using var conexion = Db.Create();
        return await conexion.QueryFirstOrDefaultAsync<Administrador>(
            "SELECT * FROM administradores WHERE usuario = @usuario", new { usuario });
    }
}

// ---------- Categorías y estados ----------
public interface ICategoriaRepository : IRepository<Categoria> { }
public class CategoriaRepository : BaseRepository<Categoria>, ICategoriaRepository
{
    public CategoriaRepository(IDbConnectionFactory db) : base(db) { }
}

public interface IEstadoRepository : IRepository<Estado> { }
public class EstadoRepository : BaseRepository<Estado>, IEstadoRepository
{
    public EstadoRepository(IDbConnectionFactory db) : base(db) { }
}

// ---------- Publicaciones ----------
public interface IPublicacionRepository : IRepository<Publicacion>
{
    Task<IEnumerable<Publicacion>> ListarActivasAsync(DateTime ahora, string? buscar);
    Task<IEnumerable<Publicacion>> ListarOcultasAsync(DateTime ahora);
    Task<Publicacion?> ObtenerConCategoriaAsync(int id);
    Task<ResumenPublicacionesDto> ResumenAsync(DateTime ahora);
}

public class PublicacionRepository : BaseRepository<Publicacion>, IPublicacionRepository
{
    private const string Seleccion =
        "SELECT p.*, c.nombre AS categoria_nombre FROM publicaciones p LEFT JOIN categorias c ON c.id = p.categoria_id";

    public PublicacionRepository(IDbConnectionFactory db) : base(db) { }

    public async Task<IEnumerable<Publicacion>> ListarActivasAsync(DateTime ahora, string? buscar)
    {
        var sql = Seleccion + " WHERE (p.fecha_expiracion IS NULL OR p.fecha_expiracion > @ahora)";
        var parametros = new DynamicParameters();
        parametros.Add("ahora", ahora);
        if (!string.IsNullOrWhiteSpace(buscar))
        {
            sql += " AND (p.titulo LIKE @buscar OR p.descripcion LIKE @buscar)";
            parametros.Add("buscar", $"%{buscar.Trim()}%");
        }
        sql += " ORDER BY p.fecha_publicacion DESC, p.id DESC";
        using var conexion = Db.Create();
        return await conexion.QueryAsync<Publicacion>(sql, parametros);
    }

    public async Task<IEnumerable<Publicacion>> ListarOcultasAsync(DateTime ahora)
    {
        using var conexion = Db.Create();
        return await conexion.QueryAsync<Publicacion>(
            Seleccion + " WHERE p.fecha_expiracion IS NOT NULL AND p.fecha_expiracion <= @ahora ORDER BY p.fecha_expiracion DESC",
            new { ahora });
    }

    public async Task<Publicacion?> ObtenerConCategoriaAsync(int id)
    {
        using var conexion = Db.Create();
        return await conexion.QueryFirstOrDefaultAsync<Publicacion>(Seleccion + " WHERE p.id = @id", new { id });
    }

    public async Task<ResumenPublicacionesDto> ResumenAsync(DateTime ahora)
    {
        const string sql = @"
            SELECT
              CAST(COALESCE(SUM(CASE WHEN fecha_expiracion IS NULL OR fecha_expiracion > @ahora THEN 1 ELSE 0 END), 0) AS SIGNED) AS Activas,
              CAST(COALESCE(SUM(CASE WHEN fecha_expiracion IS NOT NULL AND fecha_expiracion > @ahora THEN 1 ELSE 0 END), 0) AS SIGNED) AS Temporales,
              CAST(COALESCE(SUM(CASE WHEN fecha_expiracion IS NULL THEN 1 ELSE 0 END), 0) AS SIGNED) AS Permanentes,
              CAST(COALESCE(SUM(CASE WHEN fecha_expiracion IS NOT NULL AND fecha_expiracion <= @ahora THEN 1 ELSE 0 END), 0) AS SIGNED) AS Ocultas
            FROM publicaciones";
        using var conexion = Db.Create();
        return await conexion.QuerySingleAsync<ResumenPublicacionesDto>(sql, new { ahora });
    }
}

// ---------- Imágenes de publicaciones ----------
public interface IPublicacionImagenRepository : IRepository<PublicacionImagen>
{
    Task<IEnumerable<PublicacionImagen>> ListarPorPublicacionesAsync(IEnumerable<int> publicacionIds);
    Task<int> ContarAsync(int publicacionId);
}

public class PublicacionImagenRepository : BaseRepository<PublicacionImagen>, IPublicacionImagenRepository
{
    public PublicacionImagenRepository(IDbConnectionFactory db) : base(db) { }

    public async Task<IEnumerable<PublicacionImagen>> ListarPorPublicacionesAsync(IEnumerable<int> publicacionIds)
    {
        var ids = publicacionIds.ToList();
        if (ids.Count == 0) return Enumerable.Empty<PublicacionImagen>();
        using var conexion = Db.Create();
        return await conexion.QueryAsync<PublicacionImagen>(
            "SELECT * FROM publicacion_imagenes WHERE publicacion_id IN @ids ORDER BY id", new { ids });
    }

    public async Task<int> ContarAsync(int publicacionId)
    {
        using var conexion = Db.Create();
        return await conexion.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM publicacion_imagenes WHERE publicacion_id = @publicacionId", new { publicacionId });
    }
}

// ---------- Pedidos ----------
public interface IPedidoRepository : IRepository<Pedido>
{
    Task<IEnumerable<Pedido>> ListarPorEstadoAsync(int estadoId);
    Task<Pedido?> ObtenerConEstadoAsync(int id);
    Task<bool> CambiarEstadoAsync(int id, int estadoId);
    Task<ResumenPedidosDto> ResumenAsync(int estadoId);
}

public class PedidoRepository : BaseRepository<Pedido>, IPedidoRepository
{
    private const string Seleccion =
        "SELECT p.*, e.nombre AS estado_nombre FROM pedidos p JOIN estados e ON e.id = p.estado_id";

    public PedidoRepository(IDbConnectionFactory db) : base(db) { }

    public async Task<IEnumerable<Pedido>> ListarPorEstadoAsync(int estadoId)
    {
        // Los próximos se ordenan por cercanía de entrega; los demás, del más reciente al más antiguo.
        var orden = estadoId == 1 ? "p.fecha_entrega ASC" : "p.fecha_entrega DESC";
        using var conexion = Db.Create();
        return await conexion.QueryAsync<Pedido>($"{Seleccion} WHERE p.estado_id = @estadoId ORDER BY {orden}", new { estadoId });
    }

    public async Task<Pedido?> ObtenerConEstadoAsync(int id)
    {
        using var conexion = Db.Create();
        return await conexion.QueryFirstOrDefaultAsync<Pedido>($"{Seleccion} WHERE p.id = @id", new { id });
    }

    public async Task<bool> CambiarEstadoAsync(int id, int estadoId)
    {
        using var conexion = Db.Create();
        return await conexion.ExecuteAsync("UPDATE pedidos SET estado_id = @estadoId WHERE id = @id", new { id, estadoId }) > 0;
    }

    public async Task<ResumenPedidosDto> ResumenAsync(int estadoId)
    {
        const string sql = @"
            SELECT CAST(COUNT(*) AS SIGNED) AS Cantidad,
                   COALESCE(SUM(resta), 0) AS PorCobrar,
                   COALESCE(SUM(anticipo), 0) AS AnticiposRecibidos
            FROM pedidos WHERE estado_id = @estadoId";
        using var conexion = Db.Create();
        return await conexion.QuerySingleAsync<ResumenPedidosDto>(sql, new { estadoId });
    }
}
