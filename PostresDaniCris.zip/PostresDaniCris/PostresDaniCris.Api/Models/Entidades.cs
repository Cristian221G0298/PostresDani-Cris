using System.ComponentModel.DataAnnotations.Schema;

namespace PostresDaniCris.Api.Models;

[Table("administradores")]
public class Administrador
{
    public int Id { get; set; }
    public string Usuario { get; set; } = "";
    public string ContrasenaHash { get; set; } = "";
}

[Table("categorias")]
public class Categoria
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}

[Table("estados")]
public class Estado
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
}

[Table("publicaciones")]
public class Publicacion
{
    public int Id { get; set; }
    public string Titulo { get; set; } = "";
    public string? Descripcion { get; set; }
    public int? CategoriaId { get; set; }
    public DateTime FechaPublicacion { get; set; }
    public DateTime? FechaExpiracion { get; set; }
    public decimal? Precio { get; set; }
    public bool PrecioDesde { get; set; }
    public int? Cantidad { get; set; }
    public string? Lugar { get; set; }
    public bool Disponible { get; set; } = true;

    [NotMapped] public string? CategoriaNombre { get; set; }
}

[Table("publicacion_imagenes")]
public class PublicacionImagen
{
    public int Id { get; set; }
    public int PublicacionId { get; set; }
    public string Ruta { get; set; } = "";
}

[Table("pedidos")]
public class Pedido
{
    public int Id { get; set; }
    public string ANombreDe { get; set; } = "";
    public string DetallesPedido { get; set; } = "";
    public decimal Anticipo { get; set; }
    public decimal Resta { get; set; }
    public DateTime FechaAgendado { get; set; }
    public DateTime FechaEntrega { get; set; }
    public string LugarEntrega { get; set; } = "";
    public int EstadoId { get; set; } = 1;

    [NotMapped] public string? EstadoNombre { get; set; }
}
