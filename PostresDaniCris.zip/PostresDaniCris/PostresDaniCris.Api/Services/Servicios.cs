using AutoMapper;
using PostresDaniCris.Api.DTOs;
using PostresDaniCris.Api.Helpers;
using PostresDaniCris.Api.Models;
using PostresDaniCris.Api.Repositories;

namespace PostresDaniCris.Api.Services;

// ---------- Autenticación ----------
public interface IAuthService
{
    Task<Administrador?> ValidarAsync(string usuario, string contrasena);
}

public class AuthService : IAuthService
{
    private readonly IAdministradorRepository _admins;
    public AuthService(IAdministradorRepository admins) => _admins = admins;

    public async Task<Administrador?> ValidarAsync(string usuario, string contrasena)
    {
        var admin = await _admins.ObtenerPorUsuarioAsync(usuario.Trim());
        if (admin is null) return null;
        return PasswordHasher.Verificar(contrasena, admin.ContrasenaHash) ? admin : null;
    }
}

// ---------- Catálogos ----------
public interface ICatalogoService
{
    Task<List<CategoriaDto>> CategoriasAsync();
    Task<List<EstadoDto>> EstadosAsync();
}

public class CatalogoService : ICatalogoService
{
    private readonly ICategoriaRepository _categorias;
    private readonly IEstadoRepository _estados;
    private readonly IMapper _mapper;

    public CatalogoService(ICategoriaRepository categorias, IEstadoRepository estados, IMapper mapper)
    {
        _categorias = categorias;
        _estados = estados;
        _mapper = mapper;
    }

    public async Task<List<CategoriaDto>> CategoriasAsync() =>
        _mapper.Map<List<CategoriaDto>>((await _categorias.GetAllAsync()).OrderBy(c => c.Id));

    public async Task<List<EstadoDto>> EstadosAsync() =>
        _mapper.Map<List<EstadoDto>>((await _estados.GetAllAsync()).OrderBy(e => e.Id));
}

// ---------- Publicaciones ----------
public interface IPublicacionService
{
    Task<List<PublicacionDto>> ListarActivasAsync(string? buscar, int? categoriaId);
    Task<List<PublicacionDto>> ListarOcultasAsync();
    Task<PublicacionDto> ObtenerAsync(int id);
    Task<PublicacionDto> CrearAsync(PublicacionRequest solicitud);
    Task<PublicacionDto> ActualizarAsync(int id, PublicacionRequest solicitud);
    Task EliminarAsync(int id);
    Task<PublicacionDto> RepublicarAsync(int id, DateTime fechaExpiracion);
    Task<PublicacionDto> AgregarImagenesAsync(int id, IReadOnlyList<IFormFile> archivos);
    Task EliminarImagenAsync(int id, int imagenId);
    Task<ResumenPublicacionesDto> ResumenAsync();
}

public class PublicacionService : IPublicacionService
{
    private const string CategoriaNuevos = "Nuevos productos";
    private const int DiasComoNuevo = 7;
    private const int MaximoImagenes = 5;
    private const long MaximoBytes = 5 * 1024 * 1024;
    private static readonly string[] Extensiones = { ".jpg", ".jpeg", ".png", ".webp" };

    private readonly IPublicacionRepository _publicaciones;
    private readonly IPublicacionImagenRepository _imagenes;
    private readonly ICategoriaRepository _categorias;
    private readonly IMapper _mapper;
    private readonly IReloj _reloj;
    private readonly IWebHostEnvironment _env;

    public PublicacionService(IPublicacionRepository publicaciones, IPublicacionImagenRepository imagenes,
        ICategoriaRepository categorias, IMapper mapper, IReloj reloj, IWebHostEnvironment env)
    {
        _publicaciones = publicaciones;
        _imagenes = imagenes;
        _categorias = categorias;
        _mapper = mapper;
        _reloj = reloj;
        _env = env;
    }

    private string CarpetaImagenes() =>
        Path.Combine(_env.WebRootPath ?? Path.Combine(_env.ContentRootPath, "wwwroot"), "uploads", "publicaciones");

    private async Task<List<PublicacionDto>> ConImagenesAsync(IEnumerable<Publicacion> publicaciones)
    {
        var lista = publicaciones.ToList();
        var imagenes = (await _imagenes.ListarPorPublicacionesAsync(lista.Select(p => p.Id))).ToLookup(i => i.PublicacionId);
        var dtos = _mapper.Map<List<PublicacionDto>>(lista);
        foreach (var dto in dtos) dto.Imagenes = _mapper.Map<List<ImagenDto>>(imagenes[dto.Id].ToList());
        return dtos;
    }

    public async Task<List<PublicacionDto>> ListarActivasAsync(string? buscar, int? categoriaId)
    {
        var ahora = _reloj.Ahora();
        var lista = (await _publicaciones.ListarActivasAsync(ahora, buscar)).ToList();

        // "Nuevos productos" dura 7 días; después se muestra sin categoría.
        foreach (var p in lista)
        {
            if (p.CategoriaNombre == CategoriaNuevos && p.FechaPublicacion.AddDays(DiasComoNuevo) <= ahora)
            {
                p.CategoriaId = null;
                p.CategoriaNombre = null;
            }
        }
        if (categoriaId.HasValue) lista = lista.Where(p => p.CategoriaId == categoriaId).ToList();
        return await ConImagenesAsync(lista);
    }

    public async Task<List<PublicacionDto>> ListarOcultasAsync() =>
        await ConImagenesAsync(await _publicaciones.ListarOcultasAsync(_reloj.Ahora()));

    public async Task<PublicacionDto> ObtenerAsync(int id)
    {
        var publicacion = await _publicaciones.ObtenerConCategoriaAsync(id)
            ?? throw new NoEncontradoException("La publicación no existe");
        return (await ConImagenesAsync(new[] { publicacion })).First();
    }

    private async Task ValidarReglasAsync(PublicacionRequest s)
    {
        if (s.CategoriaId.HasValue && await _categorias.GetByIdAsync(s.CategoriaId.Value) is null)
            throw new ReglaNegocioException("La categoría no existe");
        if (s.FechaExpiracion.HasValue && s.FechaExpiracion.Value <= _reloj.Ahora())
            throw new ReglaNegocioException("La fecha en que se oculta debe ser posterior a este momento");
    }

    public async Task<PublicacionDto> CrearAsync(PublicacionRequest solicitud)
    {
        await ValidarReglasAsync(solicitud);
        var entidad = _mapper.Map<Publicacion>(solicitud);
        entidad.FechaPublicacion = _reloj.Ahora();
        var id = await _publicaciones.InsertAsync(entidad);
        return await ObtenerAsync(id);
    }

    public async Task<PublicacionDto> ActualizarAsync(int id, PublicacionRequest solicitud)
    {
        var existente = await _publicaciones.GetByIdAsync(id) ?? throw new NoEncontradoException("La publicación no existe");
        // Si no cambió la fecha de expiración no se vuelve a exigir que sea futura (por ejemplo, al editar una oculta).
        if (solicitud.FechaExpiracion != existente.FechaExpiracion) await ValidarReglasAsync(solicitud);
        else if (solicitud.CategoriaId.HasValue && await _categorias.GetByIdAsync(solicitud.CategoriaId.Value) is null)
            throw new ReglaNegocioException("La categoría no existe");

        var fechaPublicacion = existente.FechaPublicacion;
        _mapper.Map(solicitud, existente);
        existente.FechaPublicacion = fechaPublicacion;
        await _publicaciones.UpdateAsync(existente);
        return await ObtenerAsync(id);
    }

    public async Task EliminarAsync(int id)
    {
        if (await _publicaciones.GetByIdAsync(id) is null) throw new NoEncontradoException("La publicación no existe");
        var imagenes = (await _imagenes.ListarPorPublicacionesAsync(new[] { id })).ToList();
        await _publicaciones.DeleteAsync(id); // las filas de imágenes se borran en cascada
        foreach (var imagen in imagenes) BorrarArchivo(imagen.Ruta);
    }

    public async Task<PublicacionDto> RepublicarAsync(int id, DateTime fechaExpiracion)
    {
        var existente = await _publicaciones.GetByIdAsync(id) ?? throw new NoEncontradoException("La publicación no existe");
        var ahora = _reloj.Ahora();
        if (fechaExpiracion <= ahora) throw new ReglaNegocioException("La fecha en que se oculta debe ser posterior a este momento");
        existente.FechaPublicacion = ahora;
        existente.FechaExpiracion = fechaExpiracion;
        await _publicaciones.UpdateAsync(existente);
        return await ObtenerAsync(id);
    }

    public async Task<PublicacionDto> AgregarImagenesAsync(int id, IReadOnlyList<IFormFile> archivos)
    {
        if (await _publicaciones.GetByIdAsync(id) is null) throw new NoEncontradoException("La publicación no existe");
        if (archivos.Count == 0) throw new ReglaNegocioException("Selecciona al menos una foto");
        if (await _imagenes.ContarAsync(id) + archivos.Count > MaximoImagenes)
            throw new ReglaNegocioException($"Cada publicación puede tener máximo {MaximoImagenes} fotos");

        foreach (var archivo in archivos)
        {
            var extension = Path.GetExtension(archivo.FileName).ToLowerInvariant();
            if (!Extensiones.Contains(extension)) throw new ReglaNegocioException("Solo se permiten fotos JPG, PNG o WEBP");
            if (archivo.Length == 0 || archivo.Length > MaximoBytes) throw new ReglaNegocioException("Cada foto debe pesar máximo 5 MB");
        }

        Directory.CreateDirectory(CarpetaImagenes());
        foreach (var archivo in archivos)
        {
            var nombre = Guid.NewGuid().ToString("N") + Path.GetExtension(archivo.FileName).ToLowerInvariant();
            await using (var flujo = File.Create(Path.Combine(CarpetaImagenes(), nombre)))
                await archivo.CopyToAsync(flujo);
            await _imagenes.InsertAsync(new PublicacionImagen { PublicacionId = id, Ruta = "/uploads/publicaciones/" + nombre });
        }
        return await ObtenerAsync(id);
    }

    public async Task EliminarImagenAsync(int id, int imagenId)
    {
        var imagen = await _imagenes.GetByIdAsync(imagenId);
        if (imagen is null || imagen.PublicacionId != id) throw new NoEncontradoException("La foto no existe");
        await _imagenes.DeleteAsync(imagenId);
        BorrarArchivo(imagen.Ruta);
    }

    public Task<ResumenPublicacionesDto> ResumenAsync() => _publicaciones.ResumenAsync(_reloj.Ahora());

    private void BorrarArchivo(string ruta)
    {
        try
        {
            var archivo = Path.Combine(CarpetaImagenes(), Path.GetFileName(ruta));
            if (File.Exists(archivo)) File.Delete(archivo);
        }
        catch { /* si no se puede borrar el archivo no se detiene la operación */ }
    }
}

// ---------- Pedidos ----------
public interface IPedidoService
{
    Task<List<PedidoDto>> ListarAsync(int estadoId);
    Task<PedidoDto> ObtenerAsync(int id);
    Task<PedidoDto> CrearAsync(PedidoRequest solicitud);
    Task<PedidoDto> ActualizarAsync(int id, PedidoRequest solicitud);
    Task EliminarAsync(int id);
    Task<PedidoDto> CambiarEstadoAsync(int id, int estadoId);
    Task<ResumenPedidosDto> ResumenAsync(int estadoId);
}

public class PedidoService : IPedidoService
{
    private readonly IPedidoRepository _pedidos;
    private readonly IEstadoRepository _estados;
    private readonly IMapper _mapper;

    public PedidoService(IPedidoRepository pedidos, IEstadoRepository estados, IMapper mapper)
    {
        _pedidos = pedidos;
        _estados = estados;
        _mapper = mapper;
    }

    public async Task<List<PedidoDto>> ListarAsync(int estadoId) =>
        _mapper.Map<List<PedidoDto>>(await _pedidos.ListarPorEstadoAsync(estadoId));

    public async Task<PedidoDto> ObtenerAsync(int id) =>
        _mapper.Map<PedidoDto>(await _pedidos.ObtenerConEstadoAsync(id) ?? throw new NoEncontradoException("El pedido no existe"));

    public async Task<PedidoDto> CrearAsync(PedidoRequest solicitud)
    {
        var entidad = _mapper.Map<Pedido>(solicitud);
        entidad.FechaAgendado = solicitud.FechaAgendado.Date;
        entidad.EstadoId = 1; // Próximo
        var id = await _pedidos.InsertAsync(entidad);
        return await ObtenerAsync(id);
    }

    public async Task<PedidoDto> ActualizarAsync(int id, PedidoRequest solicitud)
    {
        var existente = await _pedidos.GetByIdAsync(id) ?? throw new NoEncontradoException("El pedido no existe");
        var estado = existente.EstadoId;
        _mapper.Map(solicitud, existente);
        existente.FechaAgendado = solicitud.FechaAgendado.Date;
        existente.EstadoId = estado;
        await _pedidos.UpdateAsync(existente);
        return await ObtenerAsync(id);
    }

    public async Task EliminarAsync(int id)
    {
        if (!await _pedidos.DeleteAsync(id)) throw new NoEncontradoException("El pedido no existe");
    }

    public async Task<PedidoDto> CambiarEstadoAsync(int id, int estadoId)
    {
        if (await _estados.GetByIdAsync(estadoId) is null) throw new ReglaNegocioException("Estado no válido");
        if (!await _pedidos.CambiarEstadoAsync(id, estadoId)) throw new NoEncontradoException("El pedido no existe");
        return await ObtenerAsync(id);
    }

    public Task<ResumenPedidosDto> ResumenAsync(int estadoId) => _pedidos.ResumenAsync(estadoId);
}
