using System.Security.Cryptography;
using System.Text;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using MySqlConnector;

namespace PostresDaniCris.Api.Helpers;

// ---------- Conexión a MySQL (la cadena sale de appsettings.json) ----------
public interface IDbConnectionFactory
{
    MySqlConnection Create();
}

public class MySqlConnectionFactory : IDbConnectionFactory
{
    private readonly string _cadena;
    public MySqlConnectionFactory(string cadena) => _cadena = cadena;
    public MySqlConnection Create() => new(_cadena);
}

// ---------- Hora local del negocio (Coahuila) ----------
public interface IReloj
{
    DateTime Ahora();
}

public class Reloj : IReloj
{
    private readonly TimeZoneInfo _zona;

    public Reloj(IConfiguration config)
    {
        var id = config["ZonaHoraria"];
        try { _zona = string.IsNullOrWhiteSpace(id) ? TimeZoneInfo.Local : TimeZoneInfo.FindSystemTimeZoneById(id); }
        catch { _zona = TimeZoneInfo.Local; }
    }

    public DateTime Ahora() => DateTime.SpecifyKind(TimeZoneInfo.ConvertTime(DateTime.UtcNow, _zona), DateTimeKind.Unspecified);
}

// ---------- Contraseñas con SHA256 (hexadecimal en minúsculas, igual que SHA2(...,256) de MySQL) ----------
public static class PasswordHasher
{
    public static string Sha256(string texto) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(texto))).ToLowerInvariant();

    public static bool Verificar(string texto, string hashGuardado)
    {
        var a = Encoding.UTF8.GetBytes(Sha256(texto));
        var b = Encoding.UTF8.GetBytes((hashGuardado ?? "").Trim().ToLowerInvariant());
        return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
    }
}

// ---------- Errores de negocio ----------
public class ReglaNegocioException : Exception
{
    public ReglaNegocioException(string mensaje) : base(mensaje) { }
}

public class NoEncontradoException : Exception
{
    public NoEncontradoException(string mensaje) : base(mensaje) { }
}

public class ManejadorErrores
{
    private readonly RequestDelegate _siguiente;
    private readonly ILogger<ManejadorErrores> _log;

    public ManejadorErrores(RequestDelegate siguiente, ILogger<ManejadorErrores> log)
    {
        _siguiente = siguiente;
        _log = log;
    }

    public async Task Invoke(HttpContext ctx)
    {
        try
        {
            await _siguiente(ctx);
        }
        catch (ReglaNegocioException ex)
        {
            await Responder(ctx, StatusCodes.Status400BadRequest, ex.Message);
        }
        catch (NoEncontradoException ex)
        {
            await Responder(ctx, StatusCodes.Status404NotFound, ex.Message);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error no controlado");
            await Responder(ctx, StatusCodes.Status500InternalServerError, "Ocurrió un error en el servidor");
        }
    }

    private static Task Responder(HttpContext ctx, int codigo, string mensaje)
    {
        ctx.Response.StatusCode = codigo;
        return ctx.Response.WriteAsJsonAsync(new { mensaje });
    }
}

// ---------- Valida automáticamente los DTO con FluentValidation ----------
public class ValidationFilter : IAsyncActionFilter
{
    private readonly IServiceProvider _servicios;
    public ValidationFilter(IServiceProvider servicios) => _servicios = servicios;

    public async Task OnActionExecutionAsync(ActionExecutingContext contexto, ActionExecutionDelegate siguiente)
    {
        foreach (var argumento in contexto.ActionArguments.Values)
        {
            if (argumento is null) continue;
            var tipo = typeof(IValidator<>).MakeGenericType(argumento.GetType());
            if (_servicios.GetService(tipo) is not IValidator validador) continue;

            var resultado = await validador.ValidateAsync(new ValidationContext<object>(argumento));
            if (resultado.IsValid) continue;

            var errores = resultado.Errors
                .GroupBy(e => char.ToLowerInvariant(e.PropertyName[0]) + e.PropertyName[1..])
                .ToDictionary(g => g.Key, g => g.Select(e => e.ErrorMessage).First());

            contexto.Result = new BadRequestObjectResult(new { mensaje = "Revisa los campos marcados", errores });
            return;
        }
        await siguiente();
    }
}
