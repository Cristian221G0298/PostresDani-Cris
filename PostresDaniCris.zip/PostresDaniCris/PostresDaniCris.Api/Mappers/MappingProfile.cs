using AutoMapper;
using PostresDaniCris.Api.DTOs;
using PostresDaniCris.Api.Models;

namespace PostresDaniCris.Api.Mappers;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Categoria, CategoriaDto>();
        CreateMap<Estado, EstadoDto>();
        CreateMap<PublicacionImagen, ImagenDto>();

        CreateMap<Publicacion, PublicacionDto>()
            .ForMember(d => d.Temporal, o => o.MapFrom(s => s.FechaExpiracion != null))
            .ForMember(d => d.Imagenes, o => o.Ignore());

        CreateMap<PublicacionRequest, Publicacion>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.FechaPublicacion, o => o.Ignore())
            .ForMember(d => d.CategoriaNombre, o => o.Ignore());

        CreateMap<Pedido, PedidoDto>();
        CreateMap<PedidoRequest, Pedido>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.EstadoId, o => o.Ignore())
            .ForMember(d => d.EstadoNombre, o => o.Ignore());
    }
}
