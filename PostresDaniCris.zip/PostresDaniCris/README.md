# Postres Dani & Cris — sitio web

Proyecto en una sola carpeta con tres partes:

| Carpeta | Qué es |
|---|---|
| `Database/` | Script SQL de MySQL (`PostresDaniCris.sql`). |
| `PostresDaniCris.Api/` | API REST en ASP.NET Core (controllers, services, repositories, mappers, validators). Es el único punto de contacto entre la base de datos y los fronts. |
| `Admin/` | Aplicación web de **administradores** (React + Vite). En PC muestra las vistas de escritorio (menú lateral) y en celular las vistas móviles. |

La aplicación de **clientes** (segunda app de React) y la conversión a **PWA** se agregan después.

## 1. Base de datos

1. Abre `Database/PostresDaniCris.sql` en tu cliente de MySQL y ejecútalo.
   Si IONOS ya te da una base creada, comenta las dos primeras líneas (`CREATE DATABASE` y `USE`).
2. Crea tu administrador (no hay registro público ni administrador sembrado):

```sql
INSERT INTO administradores (usuario, contrasena_hash)
VALUES ('dani', SHA2('TU_CONTRASENA', 256));
```

Las contraseñas se guardan con SHA256. Para cambiar una contraseña, haz un `UPDATE` con otro `SHA2(...)`.

## 2. API

1. Abre `PostresDaniCris.sln` en Visual Studio 2026.
2. En `PostresDaniCris.Api/appsettings.json` pon tu conexión en `ConnectionStrings:Default`.
3. Ejecuta el proyecto. La dirección que use (por ejemplo `https://localhost:xxxx`) es la que irá en `API_URL` del Admin.

Detalles:
- Sesión del administrador con **cookie** (sin JWT). La API responde 401 si no hay sesión.
- Fotos de publicaciones: se guardan en `wwwroot/uploads/publicaciones` y se sirven en `/uploads/...` (máx. 5 por publicación, JPG/PNG/WEBP, 5 MB cada una).
- Zona horaria: `ZonaHoraria` en `appsettings.json` (`America/Monterrey`). Es la que usa la API para decidir cuándo vence una publicación temporal.
- Si el front corriera en otro origen, agrega ese origen en `Cors:Origenes`. Con el proxy de Vite no hace falta.
- El proyecto apunta a `net10.0`. Si necesitas otra versión, cambia `TargetFramework` en el `.csproj`.

### Endpoints (todos requieren sesión, excepto login)

| Método | Ruta | Para qué |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión `{ usuario, contrasena }` |
| POST | `/api/auth/logout` | Cerrar sesión |
| GET | `/api/auth/me` | Saber si hay sesión |
| GET | `/api/categorias` | Categorías |
| GET | `/api/publicaciones?buscar=&categoriaId=` | Publicaciones vigentes |
| GET | `/api/publicaciones/ocultas` | Temporales vencidas |
| GET | `/api/publicaciones/resumen` | Totales (activas, temporales, permanentes, ocultas) |
| GET/POST | `/api/publicaciones` · `/api/publicaciones/{id}` | Ver / crear |
| PUT/DELETE | `/api/publicaciones/{id}` | Editar / eliminar |
| POST | `/api/publicaciones/{id}/republicar` | Volver a publicar `{ fechaExpiracion }` |
| POST/DELETE | `/api/publicaciones/{id}/imagenes[/{imagenId}]` | Subir / quitar fotos |
| GET | `/api/pedidos?estadoId=1` | Pedidos por estado (1 Próximo, 2 Entregado, 3 Cancelado) |
| GET | `/api/pedidos/resumen?estadoId=1` | Por cobrar, anticipos y cantidad |
| GET/POST | `/api/pedidos` · `/api/pedidos/{id}` | Ver / crear |
| PUT/DELETE | `/api/pedidos/{id}` | Editar / eliminar |
| PATCH | `/api/pedidos/{id}/estado` | Marcar entregado, cancelar o volver a próximo |

Reglas que aplica la API: "Nuevos productos" se muestra sin categoría a los 7 días; las temporales se ocultan solas al vencer; los próximos se ordenan por cercanía de entrega.

## 3. Admin (React)

Requiere Node.js.

```bash
cd Admin
cp .env.example .env     # y escribe en API_URL la dirección de la API
npm install
npm run dev
```

Abre la dirección que muestra Vite (normalmente `http://localhost:5173`).
En desarrollo, Vite reenvía `/api` y `/uploads` a la API, así el navegador usa un solo origen y la cookie de sesión funciona.

Para publicar: `npm run build` genera la carpeta `dist/`. Lo ideal es servirla bajo el mismo dominio que la API (por ejemplo, el sitio en `/` y la API en `/api`).

### Pantallas

Login · Publicaciones (estadísticas, filtros, tarjetas del mismo tamaño) · Nueva/Editar publicación en 2 pasos con vista previa · Publicaciones ocultas con republicar · Agenda de pedidos (Próximos / Entregados / Cancelados, detalles desplegables, menú de opciones) · Nuevo/Editar pedido en 2 pasos con resumen.

Pendiente de poner: el logo real (hoy es un círculo "D&C" en `src/components/ui.jsx` y `src/pages/Login.jsx`).
